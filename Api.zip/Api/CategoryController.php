<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use Response;
class CategoryController extends Controller
{
    public function index($language_id = null)
    {
    	try 
    	{
            $categories = array();
            $query = DB::table('categories');
            if ($language_id && $language_id == 'ar') 
            {
                $query->where('lang', $language_id);
            }
            if($language_id && $language_id == 'en')
            {
                $query->where('lang', $language_id);
            }
            $query->whereNull('deleted_at');
            $query->where(["status" => 1]);
            $query->where(["parent_id" => 0]);
            $query->orderBy('order_number', 'ASC');
            $query->select('id','name','alias','mobile_image_url','is_featured');
            $db_cats = $query->get();

    		if(count($db_cats) == 0)
    		{
    			return response()->json(['status_code' => 404, 'error' => 'Record not found', 'status' => false],404);
    		}
    		return response()->json(['data' => $db_cats, 'status_code' => 200, 'status' => true],200);	
    	} 
    	catch (Exception $e) 
    	{
    		return Response::json(['status_code' => 500, 'error' => 'There is something wrong', 'status' => false], 500);
    	}
    }

    public function sub_category($id, $language_id)
    {

       try 
       {
            $query = DB::table("categories");
            if ($language_id && $language_id == 'ar')
            {
                $query->select(DB::raw('id,IFNULL(ar_name, name) AS `name`,alias,IFNULL(mobile_image_url, image_url) AS `image_url`,is_featured'));
            }
            else
            {
                $query->select(DB::raw('id,name,alias,image_url ,IFNULL(mobile_image_url, image_url) AS `image_url`,is_featured'));
            }
            $query->whereNull('deleted_at');
            $query->where(['parent_id' => $id]);
            $query->orderBy('order_number', 'ASC');
            $sub_cats = $query->get();

           if(count($sub_cats) == 0)
            {
                return response()->json(['status_code' => 404, 'error' => 'Record not found', 'status' => false],404);
            }  
            return response()->json(['data' => $sub_cats, 'status_code' => 200, 'status' => true],200); 
        } 
        catch (Exception $e) 
        {
            return Response::json(['status_code' => 500, 'error' => 'There is something wrong', 'status' => false], 500);
        }
    }
   

    
}
