<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Dispute;
use App\User;
use App\Orders;
use Mockery\Exception;
use App\Mail\OrderDisputeMailToAdmin;
use DB;
use Response;
use Validator;
use Mail;

class OrderController extends Controller
{
    public $user;
    public function __construct()
    {
        $this->user = \JWTAuth::parseToken()->toUser();
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
        try 
        {
            $order_data = Orders::where('user_id', $this->user->id)
                ->where('status' ,'!=','unPaid')
                ->where('status' ,'!=','cancelled')
                ->where('status' ,'!=','declined')
                ->orderBy('id', 'desc')
                ->select('id','order_number','total_price','status','created_at')
                ->get();
            if(empty($order_data))
            {
                return response()->json(['status_code'=>404, 'error' => 'Record Not found', 'status' => false], 404);
            }
            return Response::json(['data'=>$order_data, 'status_code'=> 200, 'status' => true ],200);
        } 
        catch (Exception $e)
        {
            return Response::json(['status_code'=>500, 'error' => 'there is something wrong', 'status' => false], 500);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       try 
       {
            
            $validator = Validator::make($request->all(), [
                'order_id' => 'required',
                'question' => 'required',
            ]);
            if($validator->fails())
            {
                return response()->json(['error' => $validator->errors(), 'status_code' => 400, 'status' => false], 400);
            }
        
            $order_id = $request->order_id;
            $message = $request->question;
            $dispute = new Dispute();
            $dispute->message = $message;
            $dispute->order_id = $order_id;
            $dispute->user_id =  $this->user->id;
            $dispute->product_id = ($request->product_id) ? $request->product_id : 0;
            $dispute->save();
            
            $order = DB::table('orders')
                ->join('users', 'users.id', '=', 'orders.user_id')
                ->select('orders.*', 'users.first_name as first_name', 'users.last_name as last_name', 
                        'users.email as email','users.phone_number')
                ->where('orders.order_number', $order_id)
                ->first();
           
            $subject = 'New dispute message';
            $order->message = $message;
            Mail::to(get_config('services.site_emails.orders'))->send(new OrderDisputeMailToAdmin($subject, $message, $order));
           return response()->json(['data' => 'Successfully inserted', 'status_code' => 200, 'status' => true],200);
       } 
       catch (Exception $e) 
       {
           return Response::json(['error' => 'There is something wrong', 'status_code' => 500, 'status' => false],500);
       }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($order_id)
    {
        try 
        {
            $search_order =  DB::table('orders')
                    ->where('orders.user_id', $this->user->id)
                    ->where('orders.id', $order_id)
                    ->leftJoin('delivery_address as da', 'orders.user_id', 'da.user_id')
                    ->leftJoin('billing_address as ba', 'orders.user_id', 'ba.user_id')
                    ->select('orders.id','order_number','total_price','buyer_credit_amount_used','discount_price','tax_amount','status','otp_status','order_details','checkout_method','orders.created_at','da.first_name','da.last_name','da.mobile','da.email','da.city','da.country','da.address1','ba.first_name as billing_first_name','ba.last_name as billing_last_name','ba.mobile as billing_mobile','ba.email as billing_email','ba.city as billing_city','ba.country as billing_country','ba.address1 as billing_address1')
                    ->get();
            if(count($search_order) == 0)
            {
                return response()->json(['message' => 'Record not found', 'status_code' => 404, 'status' => false],404);
            }
            return response()->json(['data' => $search_order, 'status_code'=> 200, 'status' => true], 200);
        } 
        catch (Exception $e) 
        {
            return Response::json(['error' => 'There is something wrong', 'status_code'=> 500, 'status' => false], 500);   
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        try 
        {
            $order = Orders::where(["id" => $id])->first();
            if(count($order) == 0)
            {
                return response()->json(['error' => 'Record not found', 'status_code' => 404, 'status' => false],404);
            }
            return response()->json(['data'=> $order, 'status_code' => 200, 'status' => true],200);
        } 
        catch (Exception $e) 
        {
            return Response::json(['status_code'=> 500, 'error' => 'There is something wrong', 'status' => false],500);    
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        try 
        {
            $validator = Validator::make($request->all(), [
                'image_url' => 'required',
            ]);
            if($validator->fails())
            {
                return response()->json(['error' => $validator->errors(), 'status_code' => 400, 'status' => false], 400);
            }
            $file = $request->file('image_url');
            $fileName = time().'.'.$file->getClientOriginalExtension();
            $destinationPath = public_path('uploads/order');
            if (!is_dir($destinationPath)) 
            {
                mkdir($destinationPath, 0777, true);
            }
            $file->move($destinationPath,$fileName);
            $image_url = '/uploads/order'.$fileName;
            

            $order_detials['receipt'] = $image_url;
            $order_detials['description'] = $request->description;

            Orders::where("id", $request->id)
                    ->where('checkout_method', 'cod')
                    ->where('status' , 'unPaid')
                    ->update([
                        'transaction_detail' => json_encode($order_detials),
                    ]);
            return response()->json(['status_code' => 200, 'message' => 'Your payment verification is under process now. You will be informed, once it is confirmed', 'status' => true],200);  
        } 
        catch (Exception $e) 
        {
            return Response::json(['status_code' => 500, 'error' => 'There is something wrong', 'status' => false],500);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    /* Search order by order number */
    public function search($order_no)
    {
        try 
        {
            $search_order =  DB::table('orders')
                    ->where('user_id', $this->user->id)
                    ->where('order_number', 'like', '%'.$order_no.'%')
                    ->select('id','order_number','total_price','status','created_at')
                    ->get();
            if(count($search_order) == 0)
            {
                return response()->json(['message' => 'Record not found', 'status_code' => 404, 'status' => false],404);
            }
            return response()->json(['data' => $search_order, 'status_code'=> 200, 'status' => true], 200);
        } 
        catch (Exception $e) 
        {
            return Response::json(['error' => 'There is something wrong', 'status_code'=> 500, 'status' => false], 500);   
        }
    }
}
