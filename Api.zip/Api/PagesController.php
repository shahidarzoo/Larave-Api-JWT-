<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Pages;
use App\Tags;
use App\ContactUs;
use Respnse;
use DB;
use Validator;
use Mail;
use App\Mail\ContactNotifyAdmin;
use App\Mail\ContactNotifyUser;
use App\Stores;
use App\Models\Category;

class PagesController extends Controller
{
	public function designer_boutique($language_id) 
    { 
        try 
        {
            
            $nquery = Stores::where([["title", "RLIKE", '^[0-9]'], ['stores.status', 1], ['hide_in_store', 0], ["p.id", '!=', null]]);
            $nquery->leftJoin('products as p', 'p.store_id', '=', 'stores.id');
            if ($language_id && $language_id == 'ar') 
            {
                $nquery->where('p.lang', $language_id);
                $nquery->select(DB::raw('DISTINCT(title),stores.slug, IFNULL(ar_title, title) AS `title`'));
            }
            if($language_id && $language_id == 'en')
            {
                $nquery->where('p.lang', $language_id);
                $nquery->select(DB::raw('DISTINCT(title),stores.slug'));
            }
            $nquery->orderBy('title');
            $numaric_stores = $nquery->get();

            $alquery = Stores::where([["title", "RLIKE", '^[A-Z]'], ['stores.status', 1], ['hide_in_store', 0], ["p.id", '!=', null],["p.deleted_at", '=', null],["p.status","=",1],["p.hide_product","=",1]]);

            //$alquery->select(DB::raw('DISTINCT(title),stores.slug'));
            if ($language_id && $language_id == 'ar') 
            {
                $alquery->where('p.lang', $language_id);
                $alquery->select(DB::raw('DISTINCT(title),stores.slug, IFNULL(ar_title, title) AS `title`'));
            }
            if($language_id && $language_id == 'en')
            {
                $alquery->where('p.lang', $language_id);
                $alquery->select(DB::raw('DISTINCT(title),stores.slug'));
            }
            $alquery->leftJoin('products as p', 'p.store_id', '=', 'stores.id');
            $alquery->where('p.lang', $language_id);
            $alquery->orderBy('title');
            $alpha_stores = $alquery->get();
            $store_data = array(
                'numaric_stores' => $numaric_stores,
                'alpha_stores' => $alpha_stores,
            );
            return response()->json(['data' => $store_data, 'status_code' => 200, 'status' => true], 200);    
        } 
        catch (Exception $e) 
        {
            return Response::json(['status_code' => 500, 'error' => 'There is something wrong', 'status' => false], 500);
        }
        
    }
    public function colors($language_id)
    {
        try 
        {
            $query = DB::table('colours');
            $query->whereNull('deleted_at');
            if($language_id && $language_id ==  'ar')
            {
                $query->select(DB::raw('id,code,price ,IFNULL(ar_name, name) AS `name`'));
            }
            if($language_id && $language_id == 'en')
            {
                $query->select('id','name','code', 'price');
            }
            $colors = $query->get();
            if(count($colors) == 0)
            {
                return response()->json(['status_code' => 404, 'error' => 'Record not found', 'status' => false],404);
            }
            return response()->json(['data' => $colors, 'status_code' => 200, 'status' => true],200);   
        } 
        catch (Exception $e) 
        {
            return Response::json(['status_code' => 500, 'error' => 'There is something wrong', 'status' => false], 500);
        }
    }
    
    public function sizes($language_id)
    {
        try 
        {
            $query = DB::table('sizes');
            $query->whereNull('deleted_at');
            if($language_id && $language_id ==  'ar')
            {
                $query->select(DB::raw('id,code,price ,IFNULL(ar_name, name) AS `name`,is_custom'));
            }
            if($language_id && $language_id == 'en')
            {
                $query->select('id','name','code', 'price','is_custom');
            }
            $colors = $query->get();
            if(count($colors) == 0)
            {
                return response()->json(['status_code' => 404, 'error' => 'Record not found', 'status' => false],404);
            }
            return response()->json(['data' => $colors, 'status_code' => 200, 'status' => true],200);   
        } 
        catch (Exception $e) 
        {
            return Response::json(['status_code' => 500, 'error' => 'There is something wrong', 'status' => false], 500);
        }
    }
    
    public function filters(Request $request, $language_id)
    {
        try 
        {
            $get_active_language_id  = $language_id;
            $segment1 = $request->segment;
            $segment_value = $request->segment_value;
            if($segment1 == ''){
                return response()->json(['Segment is required', 'status_code' => 400, 'status' => false], 400);
            }
            if($segment_value == ''){
                return response()->json(['Segment value is required', 'status_code' => 400, 'status' => false], 400);
            }
            $filters = '';
            $tags_filters = '';
            if ($segment1 == 'category') 
            {
                 $alias = $segment_value;

                $category_obj = Category::where("alias", $alias)->take(1)->first();
                $filter_type_text = $category_obj->filter_type;
                $category_id = $category_obj->id;
                if (empty($category_id) && !is_numeric($category_id)) 
                {
                    return response()->json(['Category not found', 'status_code' => 400, 'status' => false], 400);
                }
                $filters = Category::where("id", $category_id)->take(1)->value('filters');
                $filters = json_decode($filters);

                if ($get_active_language_id && $get_active_language_id != 'en') 
                {
                    $tags_query = Tags::select(DB::raw("tags.id, IFNULL(tags.ar_title, tags.title) AS `title`"));
                } 
                else 
                {
                    $tags_query = Tags::select("tags.id", "tags.title");
                }

                $tags_filters = $tags_query->join('category_to_tags as tag', 'tags.id', '=', 'tag.fk_tags_id')->where("tag.fk_category_id", $category_id)->orderBy('tags.title', 'ASC')->get();
            }
            
            $type = array();
            if(!empty($tags_filters) && count($tags_filters)>=1  && isset($filters) && in_array(6, $filters))
            {
                foreach($tags_filters as $tags)
                {
                    $type[] = array('id'=>$tags->id,'title'=>$tags->title);
                }
            }

            $color_array = array();
            if (($segment1 == "category" && isset($filters) && in_array(2, $filters)) || $segment1 != "category") 
            {
                if ($segment1 == "category" || $segment1 == "store") 
                {
                    $query = DB::table('product_variations as pv');
                    if ($get_active_language_id && $get_active_language_id != 'en') 
                    {
                        $query->select(DB::raw('DISTINCT(color_id),c.id,IFNULL(c.ar_name, c.name) AS `name`'));
                    } 
                    else 
                    {
                        $query->select(DB::raw('DISTINCT(color_id),c.id,c.name AS `name`'));
                    }
                    $query->leftJoin('products', 'pv.product_id', '=', 'products.id')
                            ->leftJoin('product_to_tags as p_to_c', 'p_to_c.fk_product_id', '=', 'products.id')
                            ->leftJoin('category_to_tags as c_to_t', 'c_to_t.fk_tags_id', '=', 'p_to_c.fk_tags_id')
                            ->leftJoin('colours as c', 'pv.color_id', '=', 'c.id')
                            ->where([
                                ['products.deleted_at', '=', null],
                                ['products.hide_product', '=', 1],
                                ['products.status', '=', 1],
                    ]);
                    if ($segment1 == "store") 
                    {
                        $query->leftJoin('stores as ss', 'products.store_id', '=', 'ss.id')->where('products.store_id', $store->id);
                    } 
                    else 
                    {
                        $query->leftJoin('category_relations', 'products.id', '=', 'category_relations.entity_id')
                                ->where([
                                    ['category_relations.cat_id', '=', $category_id],
                                    ['category_relations.relation_type', '=', "product"],
                                    ['category_relations.deleted_at', null]
                                ])->orWhere('c_to_t.fk_category_id', '=', $category_id);
                    }
                    $color_array = $query->where([
                                ['pv.deleted_at', null]
                            ])->where([
                                ['c.name', '!=', null]
                            ])->orderBy('c.name', 'ASC')->get();
                } 
                else 
                {
                    $query = DB::table('colours as c');
                    if ($get_active_language_id && $get_active_language_id != 'en') 
                    {
                        $query->select(DB::raw('c.id,IFNULL(c.ar_name, c.name) AS `name`'));
                    } 
                    else 
                    {
                        $query->select(DB::raw('c.id,c.name AS `name`'));
                    }
                    $colours = $query->where('deleted_at', null)->orderBy('name', 'ASC')->get();
                }
                
               /* if ($colours) 
                {
                    foreach ($colours as $clr_key => $clr) 
                    {
                        if (isset($color_array[$clr->id]) || $clr->name == '') 
                        {
                            continue;
                        } 
                        else 
                        {
                            $color_array[$clr->id] = array(['id'=>$clr->id,'name'=>$clr->name]);
                        }
                        
                    }
                }*/
            }
            
            $size_array = array();
            if (($segment1 == "category" && isset($filters) && in_array(3, $filters)) || $segment1 != "category") 
            {
                if ($segment1 == "category" || $segment1 == "store") 
                {
                    $query = DB::table('product_variations as pv');
                    if ($get_active_language_id && $get_active_language_id != 'en') 
                    {
                        $query->select(DB::raw('DISTINCT(size_id),s.id,s.code,IFNULL(s.ar_name, s.name) AS `name`'));
                    } 
                    else 
                    {
                        $query->select(DB::raw('DISTINCT(size_id),s.id,s.name,s.code'));
                    }
                    $query->leftJoin('products', 'pv.product_id', '=', 'products.id')
                            ->leftJoin('sizes as s', 'pv.size_id', '=', 's.id')
                            ->leftJoin('product_to_tags as p_to_c', 'p_to_c.fk_product_id', '=', 'products.id')
                            ->leftJoin('category_to_tags as c_to_t', 'c_to_t.fk_tags_id', '=', 'p_to_c.fk_tags_id')
                            ->where([
                                ['products.deleted_at', '=', null],
                                ['products.hide_product', '=', 1],
                                ['products.status', '=', 1],
                    ]);
                    if ($segment1 == "store") 
                    {
                        $query->leftJoin('stores as ss', 'products.store_id', '=', 'ss.id')->where('products.store_id', $store->id);
                    } 
                    else 
                    {
                        $query->leftJoin('category_relations', 'products.id', '=', 'category_relations.entity_id')->where([
                            ['category_relations.cat_id', '=', $category_id],
                            ['category_relations.relation_type', '=', "product"],
                            ['category_relations.deleted_at', null]
                        ])->orWhere('c_to_t.fk_category_id', '=', $category_id);
                    }
                    $size_array = $query->where([
                                ['pv.deleted_at', null],
                                ['s.code', '!=', null],
                                ['s.deleted_at', '=', null],
                            ])->orderBy('s.code', 'ASC')->get();
                } 
                else 
                {
                    $query = DB::table('sizes as s');
                    if ($get_active_language_id && $get_active_language_id != 'en') 
                    {
                        $query->select(DB::raw('s.id,s.code,IFNULL(s.ar_name, s.name) AS `name`'));
                    } 
                    else 
                    {
                        $query->select(DB::raw('s.id,s.name,s.code'));
                    }
                    $size_array = $query->where('deleted_at', null)->orderBy('code', 'ASC')->get();
                }
              /*  if ($sizes) 
                {
                    foreach ($sizes as $size_key => $size) 
                    {
                        if (isset($size_array[$size->id]) || $size->code == '') 
                        {
                            continue;
                        } 
                        else 
                        {
                            if($get_active_language_id == 'en')
                            {
                                $size_array[$size->id] = array('id'=>$size->id,'name'=>$size->code);
                            }
                            else
                            {
                                $size_array[$size->id] = array('id'=>$size->id,'name'=>$size->name);
                            }
                            
                        }
                    }
                }*/
            }

            if (($segment1 == "category" && isset($filters) && in_array(7, $filters)) || $segment1 != "category") {
                
            }
            $price = array();
            if (($segment1 == "category" && isset($filters) && in_array(4, $filters)) || $segment1 != "category") {
                if ($segment1 == "category" || $segment1 == "store") {
                    $query = DB::table('products')
                            ->select(DB::raw('MIN(products.price) as min_price,MAX(products.price) as max_price'))
                            ->leftJoin('product_to_tags as p_to_c', 'p_to_c.fk_product_id', '=', 'products.id')
                            ->leftJoin('category_to_tags as c_to_t', 'c_to_t.fk_tags_id', '=', 'p_to_c.fk_tags_id')
                            ->where([
                        ['products.deleted_at', '=', null],
                        ['products.hide_product', '=', 1],
                        ['products.status', '=', 1],
                    ]);
                    if ($segment1 == "store") {
                        $query->leftJoin('stores as ss', 'products.store_id', '=', 'ss.id')->where('products.store_id', $store->id);
                    } else {
                        $query->join('category_relations', 'products.id', '=', 'category_relations.entity_id')->where([
                            ['category_relations.cat_id', '=', $category_id],
                            ['category_relations.relation_type', '=', "product"],
                            ['category_relations.deleted_at', null]
                        ])->orWhere('c_to_t.fk_category_id', '=', $category_id);
                    }

                    $price_range = $query->first();

                    $min_price = $price_range->min_price;
                    $max_price = $price_range->max_price;
                    
                } else {
                    $min_price = helper_min_product_price();
                    $max_price = helper_max_product_price();
                }
                $price = array('min'=>$min_price,'max'=>$max_price);
            }
            
            $brands = array();
            if ($segment1 == "category" && $segment_value != 'sale') {
                $query = DB::table('stores');
                if ($get_active_language_id && $get_active_language_id != 'en') {
                        $query->select(DB::raw('DISTINCT(stores.id),IFNULL(ar_title, title) AS `title`'));
                    } else {
                        $query->select(DB::raw('DISTINCT(stores.id),title'));
                    }
                $stores = $query->join('category_relations', 'stores.id', '=', 'category_relations.entity_id')
                                ->where([
                                    ['category_relations.relation_type', '=', "store"],
                                    ['category_relations.cat_id', '=', $category_id],
                                    ['category_relations.deleted_at', null],
                                    ['stores.status', '=', 1],
                                    ['stores.deleted_at', null],
                                ])->orderBy('stores.title', 'ASC')->get();
                foreach ($stores as $stores_key => $store) {
                    if ($segment_value != "sale") {
                        $products = DB::table('products as p')->select(DB::raw('*'))
                                        ->leftJoin('category_relations as cr', 'cr.entity_id', '=', 'p.id')
                                        ->where([
                                            ['cr.relation_type', '=', 'product'],
                                            ['cr.cat_id', '=', $category_id],
                                            ['p.store_id', '=', $store->id],
                                            ['cr.deleted_at', null],
                                            ['p.lang', $get_active_language_id]
                                        ])->get();
                        if (count($products) <= 0) {
                            continue;
                        }
                        $brands[] = array('id' => $store->id, 'title' => $store->title);
                    }
                }
            }
            
            if ($segment_value == "recent") {
                $query = DB::table('stores');
                if ($get_active_language_id && $get_active_language_id != 'en') {
                        $query->select(DB::raw('DISTINCT(stores.id),IFNULL(ar_title, title) AS `title`'));
                    } else {
                        $query->select(DB::raw('DISTINCT(stores.id),title'));
                    }
                $stores = $query->join('category_relations', 'stores.id', '=', 'category_relations.entity_id')
                                ->where([
                                    ['category_relations.relation_type', '=', "store"],
                                    ['category_relations.deleted_at', null],
                                    ['stores.status', '=', 1],
                                    ['stores.deleted_at', null],
                                ])->orderBy('stores.title', 'ASC')->get();
                foreach ($stores as $stores_key => $store) {
                    $products = DB::table('products as p')->select(DB::raw('*'))
                                    ->leftJoin('category_relations as cr', 'cr.entity_id', '=', 'p.id')
                                    ->where([
                                        ['cr.relation_type', '=', 'product'],
                                        ['p.store_id', '=', $store->id],
                                        ['cr.deleted_at', null],
                                        ['p.lang', $get_active_language_id]
                                    ])->get();
                    if (count($products) <= 0) {
                        continue;
                    }
                    $brands[] = array('id' => $store->id, 'title' => $store->title);
                }
            }
            /* Convert To object */
            /*$obj_color =  json_decode(json_encode($color_array), FALSE);
            (object) $color_array;*/

            $data = array(
                'type'=>$type,
                'colors'=>$color_array,
                'size'=>$size_array,
                'price'=>$price,
                'brands'=>$brands
            );
            return response()->json(['data' => $data, 'status_code' => 200, 'status' => true],200);   
        } 
        catch (Exception $e) 
        {
            return Response::json(['status_code' => 500, 'error' => 'There is something wrong', 'status' => false], 500);
        }
    }

    public function tags($language_id)
    {
        try 
        {
            $query = DB::table('tags');
            $query->whereNull('deleted_at');
            /* Check language id */
            if($language_id && $language_id ==  'ar')
            {
                $query->where('lang', $language_id);
                $query->select(DB::raw('id,tag_type ,IFNULL(ar_title, title) AS `title`'));
            }
            if($language_id && $language_id == 'en')
            {
                $query->where('lang', $language_id);
                $query->select('id','title','tag_type');
            }
            $tags = $query->get();
            if(count($tags) == 0)
            {
                return response()->json(['status_code' => 404, 'error' => 'Record not found', 'status' => false],404);
            }
            return response()->json(['data' => $tags, 'status_code' => 200, 'status' => true],200);   
        } 
        catch (Exception $e) 
        {
            return Response::json(['status_code' => 500, 'error' => 'There is something wrong', 'status' => false], 500);
        }
    }

    public function cms($slug, $language_id)
    {
        try 
        {
            $query = DB::table('pages');
            $query->where("slug",$slug);
            if($language_id && $language_id == 'ar')
            {
            	$query->where("lang", $language_id);
            	//$query->select('id','ar_title','slug','ar_description','section', 'seo_title');
                $query->select(DB::raw('id,slug, seo_title,section, IFNULL(ar_title, title) AS `title`, IFNULL(ar_description, description) AS `description`'));
            }
            if($language_id && $language_id == 'en')
            {
            	$query->where("lang", $language_id);
            	$query->select('id','title','slug','description','section', 'seo_title');
            }
            $page = $query->first();
            if(count($page) == 0)
            {
            	return response()->json(['error' => 'page not found', 'status_code' => 404, 'status' => false], 404);
            }
            return response()->json(['data' => $page, 'status_code' => 200, 'status' => true], 200);    
        } 
        catch (Exception $e) 
        {
            return Response::json(['status_code' => 500, 'error' => 'There is something wrong', 'status' => false], 500);
        }
    }

    function faqs()
    {
        
    	try 
    	{
    		$entity_meta = mh_meta_get_by_column(array('entity_key' => 'faq', 'entity_type' => 'faq'));	
    		return response()->json(['data' => $entity_meta, 'status_code' => 200, 'status' => true], 200);    
        } 
        catch (Exception $e) 
        {
            return Response::json(['status_code' => 500, 'error' => 'There is something wrong', 'status' => false], 500);
        }
    }

    function contact_us(Request $request)
    {
        try 
        {
            $validator = Validator::make($request->all(), [
                'name' => 'required',
                'message_type' => 'required',
                'email' => 'required|string|email|max:255',
                'message' => 'required',
                'phone' => 'numeric|nullable',
                'g-recaptcha-response' => 'required|recaptcha',
            ]);
            if($validator->fails())
            {
                return response()->json(['error' => $validator->errors(), 'status_code' => 400, 'status' => false], 400);
            }
            $contactUs = new ContactUs();
            $contactUs->name = $request->name;
            $contactUs->email = $request->email;
            $contactUs->phone = $request->phone;
            $contactUs->message_type = $request->message_type;
            $contactUs->message = $request->message;
            $contactUs->save();
            
            $subject = 'Boksha.com: Contact us';
            $title = 'Contact us';
            Mail::to(get_config('services.site_emails.admin'))->send(new ContactNotifyAdmin($title, $subject, $contactUs));
            $subject = 'Boksha.com: Thanks you for Contact us';
            $title = 'Thanks you for Contact us';
            Mail::to($contactUs->email)->send(new ContactNotifyUser($title, $subject, $contactUs));

        	return response()->json(['data' => 'Successfully Submitted we will contact you soon', 'status_code' => 200, 'status' => true], 200);    
        } 
        catch (Exception $e) 
        {
            return Response::json(['status_code' => 500, 'error' => 'There is something wrong', 'status' => false], 500);
        }

    }
}
