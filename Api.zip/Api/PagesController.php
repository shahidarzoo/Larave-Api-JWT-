<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Pages;
use App\Tags;
use App\ContactUs;
use Respnse;
use DB;
use Validator;
use Mail;
use App\Mail\ContactNotifyAdmin;
use App\Mail\ContactNotifyUser;
use App\Stores;

class PagesController extends Controller
{
	public function designer_boutique() 
    { 
        try 
        {
            
            $nquery = Stores::where([["title", "RLIKE", '^[0-9]'], ['stores.status', 1], ['hide_in_store', 0], ["p.id", '!=', null]]);
            $nquery->leftJoin('products as p', 'p.store_id', '=', 'stores.id');
            $numaric_stores = $nquery->select(DB::raw('DISTINCT(title),stores.slug'))
                            ->orderBy('title')
                            ->get();
            $alpha_stores = Stores::where([["title", "RLIKE", '^[A-Z]'], ['stores.status', 1], ['hide_in_store', 0], ["p.id", '!=', null],["p.deleted_at", '=', null],["p.status","=",1],["p.hide_product","=",1]])
                        ->select(DB::raw('DISTINCT(title),stores.slug'))
                        ->leftJoin('products as p', 'p.store_id', '=', 'stores.id')
                        ->orderBy('title')
                        ->get();
            $store_data = array(
                'numaric_stores' => $numaric_stores,
                'alpha_stores' => $alpha_stores,
            );
            return response()->json(['data' => $store_data, 'status_code' => 200, 'status' => true], 200);    
        } 
        catch (Exception $e) 
        {
            return Response::json(['status_code' => 500, 'error' => 'There is something wrong', 'status' => false], 500);
        }
        
    }
    public function colors($language_id)
    {
        try 
        {
            $query = DB::table('colours');
            $query->where('deleted_at', null);
            if($language_id && $language_id ==  'ar')
            {
               $query->where('lang', $language_id);
               $query->select('id','ar_name','code', 'price');
            }
            if($language_id && $language_id == 'en')
            {
                $query->where('lang', $language_id);
                $query->select('id','name','code', 'price');
            }
            $colors = $query->get();
            if(count($colors) == 0)
            {
                return response()->json(['status_code' => 404, 'error' => 'Record not found', 'status' => false],404);
            }
            return response()->json(['data' => $colors, 'status_code' => 200, 'status' => true],200);   
        } 
        catch (Exception $e) 
        {
            return Response::json(['status_code' => 500, 'error' => 'There is something wrong', 'status' => false], 500);
        }
    }

    public function tags($language_id)
    {
        try 
        {
            $query = DB::table('tags');
            $query->where('deleted_at', null);
            /* Check language id */
            if($language_id && $language_id ==  'ar')
            {
               $query->where('lang', $language_id);
               $query->select('id','ar_title','tag_type');
            }
            if($language_id && $language_id == 'en')
            {
                $query->where('lang', $language_id);
                $query->select('id','title','tag_type');
            }
            $tags = $query->get();
            if(count($tags) == 0)
            {
                return response()->json(['status_code' => 404, 'error' => 'Record not found', 'status' => false],404);
            }
            return response()->json(['data' => $tags, 'status_code' => 200, 'status' => true],200);   
        } 
        catch (Exception $e) 
        {
            return Response::json(['status_code' => 500, 'error' => 'There is something wrong', 'status' => false], 500);
        }
    }

    public function cms($slug, $language_id)
    {
        try 
        {
            $query = DB::table('pages');
            $query->where("slug",$slug);
            if($language_id && $language_id == 'ar')
            {
            	$query->where("lang", $language_id);
            	$query->select('id','ar_title','slug','ar_description','section', 'seo_title');
            }
            if($language_id && $language_id == 'en')
            {
            	$query->where("lang", $language_id);
            	$query->select('id','title','slug','description','section', 'seo_title');
            }
            $page = $query->first();
            if(count($page) == 0)
            {
            	return response()->json(['error' => 'page not found', 'status_code' => 404, 'status' => false], 404);
            }
            return response()->json(['data' => $page, 'status_code' => 200, 'status' => true], 200);    
        } 
        catch (Exception $e) 
        {
            return Response::json(['status_code' => 500, 'error' => 'There is something wrong', 'status' => false], 500);
        }
    }

    function faqs()
    {
        
    	try 
    	{
    		$entity_meta = mh_meta_get_by_column(array('entity_key' => 'faq', 'entity_type' => 'faq'));	
    		return response()->json(['data' => $entity_meta, 'status_code' => 200, 'status' => true], 200);    
        } 
        catch (Exception $e) 
        {
            return Response::json(['status_code' => 500, 'error' => 'There is something wrong', 'status' => false], 500);
        }
    }

    function contact_us(Request $request)
    {
        try 
        {
            $validator = Validator::make($request->all(), [
                'name' => 'required',
                'message_type' => 'required',
                'email' => 'required|string|email|max:255',
                'message' => 'required',
                'phone' => 'numeric|nullable',
                'g-recaptcha-response' => 'required|recaptcha',
            ]);
            if($validator->fails())
            {
                return response()->json(['error' => $validator->errors(), 'status_code' => 400, 'status' => false], 400);
            }
            $contactUs = new ContactUs();
            $contactUs->name = $request->name;
            $contactUs->email = $request->email;
            $contactUs->phone = $request->phone;
            $contactUs->message_type = $request->message_type;
            $contactUs->message = $request->message;
            $contactUs->save();
            
            $subject = 'Boksha.com: Contact us';
            $title = 'Contact us';
            Mail::to(get_config('services.site_emails.admin'))->send(new ContactNotifyAdmin($title, $subject, $contactUs));
            $subject = 'Boksha.com: Thanks you for Contact us';
            $title = 'Thanks you for Contact us';
            Mail::to($contactUs->email)->send(new ContactNotifyUser($title, $subject, $contactUs));

        	return response()->json(['data' => 'Successfully Submitted we will contact you soon', 'status_code' => 200, 'status' => true], 200);    
        } 
        catch (Exception $e) 
        {
            return Response::json(['status_code' => 500, 'error' => 'There is something wrong', 'status' => false], 500);
        }

    }
}
