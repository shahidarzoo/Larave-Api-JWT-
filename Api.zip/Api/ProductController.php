<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Products;
use DB;
use Response;
use App\Models\Category;
use App\CustomMeasurements;
use Illuminate\Session\Store;
use App\Models\CategoryRelation;
use App\Stores;
use App\ProductVariations;
use App\Tags;

class ProductController extends Controller
{
	// Product Details
    public function index(Request $request, $language_id = null)
    {
    	try 
    	{
            $page_id = '';
            $category_obj = '';
            $order_ids = "";
            $cache_enabled = config('cache.enabled_listing_item');
            $cache_duration = config('cache.duration');
            $cache_prefix = config('cache.cache_prefix');
            $cache_enabled = false;
            $key = 'category_products_load';
            if ($request->segment(1) != NULL) 
            {
                $key .= '_' . $request->segment(1);
            }
            if ($request->segment(2) != NULL) 
            {
                $key .= '_' . $request->segment(2);
            }

            if ($_GET['page'] != NULL) 
            {
                $key .= '_' . $_GET['page'];
            }

            $query = DB::table('products');
            $query->where(["products.status" => 1, "products.hide_product" => 1, 'products.deleted_at' => null]);
            if($language_id && $language_id == 'ar')
            {
                 $query->where('lang', $language_id);
            }
            if($language_id && $language_id == 'en')
            {
                 $query->where('lang', $language_id);
            }
            $query->leftJoin('stores as ss', 'products.store_id', '=', 'ss.id');


            //apply store filter
            $store_data = "";
            $segment1 = $request->s;
            if ($segment1 == "search") 
            {
                $page_id = 'search';

                $key .= '_' . $request->s;
                $query_string = $request->s;

                $category_obj = DB::table('categories')
                                ->where("name", 'like', "%{$query_string}%")
                                ->where(["status" => 1, "parent_id" => 0, 'deleted_at' => null])
                                ->take(1)
                                ->first();
                $search_cat_id = $category_obj->id;


                $color_obj = DB::table('colours')
                            ->where("name", 'like', "%{$query_string}%")
                            ->take(1)
                            ->first();
                $color_id = $color_obj->id;
                $color_condition = '';
                if ($color_id) 
                {
                    $query->Join('product_variations as pv', 'products.id', '=', 'pv.product_id');
                    $color_condition = true;
                }

                $size_obj = DB::table('sizes')
                            ->where("name", 'like', "%{$query_string}%")
                            ->take(1)
                            ->first();
                $size_id = $size_obj->id;
                $size_condition = '';
                if ($size_id) 
                {
                    $query->Join('product_variations', 'products.id', '=', 'product_variations.product_id');
                    $size_condition = true;
                }

                $store_obj = DB::table('stores')
                            ->where("title", 'like', "%{$query_string}%")
                            ->take(1)
                            ->first();
                $store_id = $store_obj->id;
                $store_condition = '';
                if ($store_id) 
                {
                    $store_condition = true;
                }


                if ($search_cat_id) 
                {
                    $category_id = $search_cat_id;
                    $query->join('category_relations', 'products.id', '=', 'category_relations.entity_id');
                    $query->leftJoin('product_to_tags as p_to_c', 'p_to_c.fk_product_id', '=', 'products.id');
                    $query->leftJoin('category_to_tags as c_to_t', 'c_to_t.fk_tags_id', '=', 'p_to_c.fk_tags_id');
                    $query->where(function ($query) use ($category_id, $query_string) 
                    {
                        $query->orWhere([
                            ['category_relations.cat_id', '=', $category_id],
                            ['category_relations.relation_type', '=', "product"],
                            ['category_relations.deleted_at', null]
                        ])->orWhere('c_to_t.fk_category_id', '=', $category_id)
                        ->orWhere('products.name', 'like', "%{$query_string}%")
                        ->orWhere('products.short_description', 'like', "%{$query_string}%");
                    });
                } 
                else 
                {
                    $query->where(function ($query) use ($color_condition, $size_condition, $store_condition, $color_id, $size_id, $store_id, $query_string) 
                    {
                        $query->where('products.name', 'like', "%{$query_string}%")
                                ->orWhere('products.short_description', 'like', "%{$query_string}%");
                        if ($color_condition) 
                        {
                            $query->orWhere('pv.color_id', $color_id);
                        }
                        if ($size_condition) 
                        {
                            $query->orWhere('product_variations.size_id', $size_id);
                        }
                        if ($store_condition) 
                        {
                            $query->orWhere('products.store_id', $store_id);
                        }
                    });
                }
            }

            /* End search filter */
            /*Filter Recent*/
            if ($request->recent) 
            {
                $page_id = 'recent_product';
                $query->orderBy('products.created_at', 'DESC');
            }
            /*End Recent filter */

            /*Filter Tranding*/
            if ($request->trending) 
            {
                $page_id = 'trending_product';
                $query->leftJoin('order_to_store', 'products.id', '=', 'order_to_store.product_id')
                        ->groupBy('products.id')
                        ->orderBy('ids', 'desc');
                $order_ids = ",count(order_to_store.product_id) as ids";
            }
            /*End Filter Tranding*/

            //apply color filter
            if (is_array($request->colors) && count($request->colors) >= 1) 
            {
                $key .= '_' . json_encode($request->colors);
                $query->Join('product_variations as pv', 'products.id', '=', 'pv.product_id');
                $query->whereIn('pv.color_id', $request->colors);
            }

            //apply size filter
            if (is_array($request->sizes) && count($request->sizes) >= 1) 
            {
                $key .= '_' . json_encode($request->sizes);
                $query->Join('product_variations', 'products.id', '=', 'product_variations.product_id');
                $query->whereIn('product_variations.size_id', $request->sizes);
            }
            if ($request->fabric) 
            {
                $fabric = $request->fabric;
                $query->where('products.item_fabric', 'like', "%$fabric%");
            }

            //apply category filter
            $category_id = "";
            $filter_type_text = "";
            $filters = array();
            /*Filters Category */
            if ($segment1 == "category") 
            {
                $page_id = 'category';
                $alias = $request->segment(2);
                
                    $category_obj = Category::where("alias", $alias)->take(1)->first();
                    $filter_type_text = $category_obj->filter_type;
                    $category_id = $category_obj->id;
                    //dd( $category_obj->filter_type);
                if (empty($category_id) && !is_numeric($category_id)) 
                {
                    abort(404);
                }
                $query->join('category_relations', 'products.id', '=', 'category_relations.entity_id');
                $query->leftJoin('product_to_tags as p_to_c', 'p_to_c.fk_product_id', '=', 'products.id');
                $query->leftJoin('category_to_tags as c_to_t', 'c_to_t.fk_tags_id', '=', 'p_to_c.fk_tags_id');
                $query->where(function ($query) use ($category_id) 
                {
                    $query->where([
                        ['category_relations.cat_id', '=', $category_id],
                        ['category_relations.relation_type', '=', "product"],
                        ['category_relations.deleted_at', null]
                    ])->orWhere('c_to_t.fk_category_id', '=', $category_id);
                });

                $tags_filters = Tags::select("tags.id", "tags.title")
                                ->join('category_to_tags as tag', 'tags.id', '=', 'tag.fk_tags_id')
                                ->where("tag.fk_category_id", $category_id)
                                ->orderBy('tags.title', 'ASC')
                                ->get();
                if (!empty($request->tags)) 
                {
                    $key .= '_tag' . $request->tags;
                    $query->whereIn('c_to_t.fk_tags_id', $request->tags);
                }

                $filters = Category::where("id", $category_id)
                            ->take(1)
                            ->value('filters');
                $filters = json_decode($filters);
            }
            /* End Category Filter */

            //apply store filter
            $store_data = "";
            if ($segment1 == "store") 
            {
                $page_id = 'store';
                $alias = $request->segment(2);

                if ($cache_enabled) 
                {
                    $key3 = $cache_prefix . '_get_store_info_by_alias_' . $alias;
                    $store_data = Cache::remember($key3, $cache_duration, function () use ($alias) 
                    {
                        return DB::table("stores")->where([
                                ['slug', '=', $alias],
                                ['status', '=', 1],
                                ['deleted_at', null]
                                ])->take(1)
                                ->first();
                        });
                } 
                else 
                {
                    $store_data = DB::table("stores")->where([
                                ['slug', '=', $alias],
                                ['status', '=', 1],
                                ['deleted_at', null]
                            ])->take(1)->first();
                }
                $store_id = $store_data->id;
                if (empty($store_id) && !is_numeric($store_id)) 
                {
                    abort(404);
                }
                $query->where("products.store_id", $store_id);
            }
            /*End Store Filter */

            //apply ajax brand/store filter
            if (is_array($request->brands) && count($request->brands) >= 1) 
            {
                $request->brands;
                $alias = $request->segment(2);
                $query->join('stores', 'products.store_id', '=', 'stores.id')
                        ->whereIn('stores.id', $request->brands);

                $category_ids = CategoryRelation::whereIn('entity_id', $request->brands)
                                ->where('relation_type', 'store')->pluck('cat_id');
                               
                $cat_ids = [];
                foreach ($category_ids as $key => $cat_val) 
                {
                    array_push($cat_ids, $cat_val);
                }
                $query->join('category_relations as cr', 'products.id', '=', 'cr.entity_id')
                        ->where(function ($query) use ($cat_ids) 
                        {
                            $query->where(function ($query) use ($cat_ids) 
                            {
                                $query->whereIn('cr.cat_id', $cat_ids)
                                ->where('cr.relation_type', "product")
                                ->where('cr.deleted_at', null);
                            })->orWhereIn('c_to_t.fk_category_id', $cat_ids);
                        });
            }
            
            
               //apply ajax brand/store filter
            if (is_array($request->brands_new) && count($request->brands_new) >= 1) 
            {

                $request->brands_new;
                $alias = $request->segment(2);
                $query->join('stores', 'products.store_id', '=', 'stores.id')
                        ->whereIn('stores.id', $request->brands_new);

                $category_ids = CategoryRelation::whereIn('entity_id', $request->brands_new)
                                ->where('relation_type', 'store')->pluck('cat_id');
                               
                $cat_ids = [];
                foreach ($category_ids as $key => $cat_val) 
                {
                    array_push($cat_ids, $cat_val);
                }
                $query->join('category_relations as cr', 'products.id', '=', 'cr.entity_id')
                        ->where(function ($query) use ($cat_ids) 
                        {
                            $query->where(function ($query) use ($cat_ids) 
                            {
                                $query->whereIn('cr.cat_id', $cat_ids)
                                ->where('cr.relation_type', "product")
                                ->where('cr.deleted_at', null);
                            });
                        });
            }
            
               //Category Filter
            if (is_array($request->category_id2) && count($request->category_id2) >= 1) 
            {

                $category_id = $request->category_id2;           
                $alias = $request->segment(2);

                $query->join('category_relations', 'products.id', '=', 'category_relations.entity_id');
                $query->leftJoin('product_to_tags as p_to_c', 'p_to_c.fk_product_id', '=', 'products.id');
                $query->leftJoin('category_to_tags as c_to_t', 'c_to_t.fk_tags_id', '=', 'p_to_c.fk_tags_id');
                $query->whereIn('category_relations.cat_id', $category_id);
                $query->where('category_relations.relation_type', 'product');
                
                
            }


            //Price Range Filter
            if (!empty($request->price_range)) 
            {
                $key .= '_' . $request->price_range;
                $price_range = explode(";", $request->price_range);
                $query->whereBetween('products.price', [$price_range[0], $price_range[1]]);
            }
            if ($request->sort) 
            {
                $sort = $request->sort;
                $key .= '_' . $sort;
                if ($sort == 1) 
                {
                    $query->orderBy('products.created_at', 'desc');
                } 
                elseif ($sort == 2) 
                {
                    $query->orderBy('products.price', 'asc');
                } 
                elseif ($sort == 3) 
                {
                    $query->orderBy('products.price', 'desc');
                } 
                elseif ($sort == 4) 
                {
                    $query->leftJoin('order_to_store', 'products.id', '=', 'order_to_store.product_id')
                            ->groupBy('products.id')
                            ->orderBy('ids', 'desc');
                    $order_ids = ",count(order_to_store.product_id) as ids";
                }
            } 
            else if ($segment1 == "category") 
            {
                $key .= '_orderbyidss';
                $query->orderBy('products.id', 'desc');
            } 
            else 
            {
                $key .= '_productid';
                if ($segment1 == "store") 
                {
                    if($store_data->product_order_by == 1)
                    {
                        $query->orderBy('products.id', 'desc');
                    }
                    elseif($store_data->product_order_by == 2)
                    {
                        $query->orderBy('products.price', 'DESC');
                    }
                    elseif($store_data->product_order_by == 3)
                    {
                        $query->orderBy('products.price', 'ASC');
                    }
                    elseif($store_data->product_order_by == 5)
                    {
                        $query->orderBy('products.name', 'ASC');
                    }
                    elseif($store_data->product_order_by == 6)
                    {
                        $query->orderBy('products.name', 'DESC');
                    }
                    elseif($store_data->product_order_by == 7)
                    {
                        $query->leftJoin('order_to_store', 'products.id', '=', 'order_to_store.product_id')
                                ->groupBy('products.id')
                                ->orderBy('ids', 'desc');
                        $order_ids = ",count(order_to_store.product_id) as ids";
                    }
                    else
                    {
                        $cat_id = $store_data->product_order_by - 100;
                        $query->leftJoin('category_relations', 'products.id', '=', 'category_relations.entity_id');
                        $query->where([
                            ['category_relations.relation_type', '=', "product"],
                            ['category_relations.deleted_at', null]
                        ]);
                        $query->orderByRaw('FIELD(category_relations.cat_id, "'.$cat_id.'") DESC');
                    }
                }
                else
                {
                    $query->orderBy('products.id', 'desc');
                } 
            }

            $query->distinct('products.id');

            //$query = $query->select(DB::raw('DISTINCT(products.id), "products.id", "products.name", "products.short_description", "products.price", "products.sale_price", ss.offline' . $order_ids . ''));

            $query->select(['products.id','name','short_description','products.price','products.sale_price','products.is_featured','products.quantity', 'products.slug','custom_sizes','custom_sizes','url','logo_path','facebook_handle','twitter_handle','linkedin_handle','instagram_handle']);
            
            $products = $query->distinct()->paginate(10);
            /* check product exist or not */
    		if(count($products) == 0)
    		{
    			return response()->json(['status_code' => 404, 'error' => 'Records not found', 'status' => false], 404);
    		}
    		return response()->json(['data'=> $products, 'status_code' => 200, 'status' => true], 200);
    	} 
    	catch (Exception $e) 
    	{
    		return Response::json(['status_code' => 500, 'error' => 'There is an error', 'status' => false], 500);	
    	}
    }
 	// Product Base on Category
    public function category_products($alias)
    {
    	try 
    	{
            $query = DB::table('categories');
            $query->join('category_relations', 'categories.id', '=', 'category_relations.cat_id');
            $query->leftJoin('products', 'category_relations.entity_id', '=', 'products.id');
            $query->leftJoin('stores', 'products.store_id', '=', 'stores.id');
            $query->leftJoin('product_to_tags as ptags', 'products.id','=', 'ptags.fk_product_id');
            $query->leftJoin('category_to_tags as ctags', 'ctags.fk_tags_id', '=', 'categories.id');
            $query->groupBy('products.store_id');
            $query->where('category_relations.deleted_at', null);
            $query->where('categories.alias',$alias);
            $query->where('categories.deleted_at',null);
            $query->select('products.id', 'products.name','products.price', 'products.sale_price','products.description','products.no_of_days','products.item_fabric','categories.image_url','categories.order_number','products.slug','products.custom_sizes','products.category_fields');
             $product_to_cateogry = $query->paginate(10);

             /* Check the category exist or not */
    		if(count($product_to_cateogry) == 0)
    		{
    			return response()->json(['status_code' => 404, 'error' => 'Records not fount', 'status' => false], 404);
    		}
    		return response()->json(['data' => $product_to_cateogry, 'status_code' => 200, 'status' => true], 200);
    	} 
    	catch (Exception $e) 
    	{
    		return Response::json(['status_code' => 500, 'error' => 'There is something wrong', 'status' => false], 500);
    	}
    }
    // single product with slug
    public function show($slug)
    {
    	try 
    	{
            $query = DB::table('products');
            $query->where('products.deleted_at', '=', Null);
            $query->where('products.slug', $slug);
            $query->groupBy('products.store_id');
            $product = $query->first();
    		if(count($product) == 0)
    		{
    			return response()->json(['status_code' => 404, 'error' => 'Record not found', 'status' => false], 404);
    		}
    		return response()->json(['data' => $product, 'status_code' => 200, 'status' => true], 200);
    	} 
    	catch (Exception $e) 
    	{
    		return Response::json(['status_code' => 500, 'error' => 'There is some thing wrong', 'status' => false], 500);
    	}
    }

    public function search(Request $request, $language_id)
    {
        try 
        {
            $page_id = '';
            $category_obj = '';

            $order_ids = "";
            $cache_enabled = config('cache.enabled_listing_item');
            $cache_duration = config('cache.duration');
            $cache_prefix = config('cache.cache_prefix');
            $cache_enabled = false;

            $key = 'category_products_load';
            if ($request->segment(2) != NULL) 
            {
                $key .= '_' . $request->segment(1);
            }
            if ($request->segment(3) != NULL) 
            {
                $key .= '_' . $request->segment(2);
            }

            if ($_GET['page'] != NULL) 
            {
                $key .= '_' . $_GET['page'];
            }
            $query = DB::table('products');
            $query->where(["products.status" => 1, "products.hide_product" => 1, 'products.deleted_at' => null]);
            if($language_id && $language_id == 'ar')
            {
                 $query->where('lang', $language_id);
            }
            if($language_id && $language_id == 'en')
            {
                 $query->where('lang', $language_id);
            }
            $query->leftJoin('stores as ss', 'products.store_id', '=', 'ss.id');
            
            $store_data = "";
            $segment1 = $request->segment(1);
            
            $page_id = 'search';

            $key .= '_' . $request->name;
            $query_string = $request->name;

            $category_obj = DB::table('categories')->where("name", 'like', "%{$query_string}%")->where(["status" => 1, "parent_id" => 0, 'deleted_at' => null])->take(1)->first();
            $search_cat_id = $category_obj->id;


            $color_obj = DB::table('colours')->where("name", 'like', "%{$query_string}%")->take(1)->first();
            $color_id = $color_obj->id;

            $color_condition = '';
            if ($color_id) 
            {
                $query->Join('product_variations as pv', 'products.id', '=', 'pv.product_id');
                $color_condition = true;
            }

            $size_obj = DB::table('sizes')->where("name", 'like', "%{$query_string}%")->take(1)->first();
            $size_id = $size_obj->id;
            $size_condition = '';
            if ($size_id) 
            {
                $query->Join('product_variations', 'products.id', '=', 'product_variations.product_id');
                $size_condition = true;
            }

            $store_obj = DB::table('stores')->where("title", 'like', "%{$query_string}%")->take(1)->first();
            $store_id = $store_obj->id;

            $store_condition = '';
            if ($store_id) 
            {
                $store_condition = true;
            }


            if ($search_cat_id) 
            {
                $category_id = $search_cat_id;
                $query->join('category_relations', 'products.id', '=', 'category_relations.entity_id');
                $query->leftJoin('product_to_tags as p_to_c', 'p_to_c.fk_product_id', '=', 'products.id');
                $query->leftJoin('category_to_tags as c_to_t', 'c_to_t.fk_tags_id', '=', 'p_to_c.fk_tags_id');
                $query->where(function ($query) use ($category_id, $query_string) 
                {
                    $query->orWhere([
                        ['category_relations.cat_id', '=', $category_id],
                        ['category_relations.relation_type', '=', "product"],
                        ['category_relations.deleted_at', null]
                    ])->orWhere('c_to_t.fk_category_id', '=', $category_id)
                    ->orWhere('products.name', 'like', "%{$query_string}%")
                    ->orWhere('products.short_description', 'like', "%{$query_string}%");
                });
                
            } 
            else 
            {
                $query->where(function ($query) use ($color_condition, $size_condition, $store_condition, $color_id, $size_id, $store_id, $query_string) 
                {
                    $query->where('products.name', 'like', "%{$query_string}%")
                            ->orWhere('products.short_description', 'like', "%{$query_string}%");
                    if ($color_condition) 
                    {
                        $query->orWhere('pv.color_id', $color_id);
                    }
                    if ($size_condition) 
                    {
                        $query->orWhere('product_variations.size_id', $size_id);
                    }
                    if ($store_condition) 
                    {
                        $query->orWhere('products.store_id', $store_id);
                    }
                });
            }
            if ($request->segment(3) != NULL && $request->segment(2) == "recent") 
            {
                $page_id = 'recent_product';
                $query->orderBy('products.created_at', 'DESC');
            }
            if ($request->segment(3) != NULL && $request->segment(2) == "trending") 
            {
                $page_id = 'trending_product';
                $query->leftJoin('order_to_store', 'products.id', '=', 'order_to_store.product_id')
                    ->groupBy('products.id')
                    ->orderBy('ids', 'desc');
                $order_ids = ",count(order_to_store.product_id) as ids";
            }

            //apply color filter
            if (is_array($request->colors) && count($request->colors) >= 1) 
            {
                $key .= '_' . json_encode($request->colors);
                $query->Join('product_variations as pv', 'products.id', '=', 'pv.product_id');
                $query->whereIn('pv.color_id', $request->colors);
            }
            //apply size filter
            if (is_array($request->sizes) && count($request->sizes) >= 1) 
            {
                $key .= '_' . json_encode($request->sizes);
                $query->Join('product_variations', 'products.id', '=', 'product_variations.product_id');
                $query->whereIn('product_variations.size_id', $request->sizes);
            }
            if($request->fabric) 
            {
                $fabric = $request->fabric;
                $query->where('products.item_fabric', 'like', "%{$fabric}%");
            }

            //apply category filter
            $category_id = "";
            $filter_type_text = "";
            $filters = array();
            if ($segment1 == "category") 
            {
                $page_id = 'category';
                $alias = $request->segment(2);
                
                    $category_obj = Category::where("alias", $alias)->take(1)->first();
                    $filter_type_text = $category_obj->filter_type;
                    $category_id = $category_obj->id;
                    //dd( $category_obj->filter_type);
                if (empty($category_id) && !is_numeric($category_id)) 
                {
                    abort(404);
                }
                $query->join('category_relations', 'products.id', '=', 'category_relations.entity_id');
                $query->leftJoin('product_to_tags as p_to_c', 'p_to_c.fk_product_id', '=', 'products.id');
                $query->leftJoin('category_to_tags as c_to_t', 'c_to_t.fk_tags_id', '=', 'p_to_c.fk_tags_id');
                $query->where(function ($query) use ($category_id) 
                {
                    $query->where([
                        ['category_relations.cat_id', '=', $category_id],
                        ['category_relations.relation_type', '=', "product"],
                        ['category_relations.deleted_at', null]
                    ])->orWhere('c_to_t.fk_category_id', '=', $category_id);
                });

                $tags_filters = Tags::select("tags.id", "tags.title")
                                ->join('category_to_tags as tag', 'tags.id', '=', 'tag.fk_tags_id')
                                ->where("tag.fk_category_id", $category_id)
                                ->orderBy('tags.title', 'ASC')
                                ->get();
                if (!empty($request->tags)) 
                {
                    $key .= '_tag' . $request->tags;
                    $query->whereIn('c_to_t.fk_tags_id', $request->tags);
                }

                $filters = Category::where("id", $category_id)
                            ->take(1)
                            ->value('filters');
                $filters = json_decode($filters);
            }
            //apply store filter
            $store_data = "";
            if ($segment1 == "store") 
            {
                $page_id = 'store';
                $alias = $request->segment(2);

                if ($cache_enabled) 
                {
                    $key3 = $cache_prefix . '_get_store_info_by_alias_' . $alias;
                    $store_data = Cache::remember($key3, $cache_duration, function () use ($alias) 
                    {
                        return DB::table("stores")->where([
                            ['slug', '=', $alias],
                            ['status', '=', 1],
                            ['deleted_at', null]
                        ])->take(1)
                        ->first();
                        });
                } 
                else 
                {
                    $store_data = DB::table("stores")->where([
                            ['slug', '=', $alias],
                            ['status', '=', 1],
                            ['deleted_at', null]
                        ])->take(1)
                        ->first();
                }
                $store_id = $store_data->id;
                if (empty($store_id) && !is_numeric($store_id)) 
                {
                    abort(404);
                }
                $query->where("products.store_id", $store_id);
            }
            //apply ajax brand/store filter
            if (is_array($request->brands) && count($request->brands) >= 1) 
            {
                $request->brands;
                $alias = $request->segment(2);
                $query->join('stores', 'products.store_id', '=', 'stores.id')
                        ->whereIn('stores.id', $request->brands);

                $category_ids = CategoryRelation::whereIn('entity_id', $request->brands)
                                ->where('relation_type', 'store')
                                ->pluck('cat_id');
                               
                $cat_ids = [];
                foreach ($category_ids as $key => $cat_val) 
                {
                    array_push($cat_ids, $cat_val);
                }
                $query->join('category_relations as cr', 'products.id', '=', 'cr.entity_id')
                        ->where(function ($query) use ($cat_ids) {
                            $query->where(function ($query) use ($cat_ids) {
                                $query->whereIn('cr.cat_id', $cat_ids)
                                ->where('cr.relation_type', "product")
                                ->where('cr.deleted_at', null);
                            })->orWhereIn('c_to_t.fk_category_id', $cat_ids);
                        });
            }
            
               /* apply ajax brand/store filter */
            if (is_array($request->brands_new) && count($request->brands_new) >= 1) 
            {

                $request->brands_new;
                $alias = $request->segment(2);
                $query->join('stores', 'products.store_id', '=', 'stores.id')
                        ->whereIn('stores.id', $request->brands_new);

                $category_ids = CategoryRelation::whereIn('entity_id', $request->brands_new)
                                ->where('relation_type', 'store')
                                ->pluck('cat_id');
                               
                $cat_ids = [];
                foreach ($category_ids as $key => $cat_val) 
                {
                    array_push($cat_ids, $cat_val);
                }
                $query->join('category_relations as cr', 'products.id', '=', 'cr.entity_id')
                        ->where(function ($query) use ($cat_ids) 
                        {
                            $query->where(function ($query) use ($cat_ids) 
                            {
                                $query->whereIn('cr.cat_id', $cat_ids)
                                ->where('cr.relation_type', "product")
                                ->where('cr.deleted_at', null);
                            });
                        });
            } 
               //Category Filter
            if (is_array($request->category_id2) && count($request->category_id2) >= 1) 
            {

                $category_id = $request->category_id2;           
                $alias = $request->segment(2);

                $query->join('category_relations', 'products.id', '=', 'category_relations.entity_id');
                $query->leftJoin('product_to_tags as p_to_c', 'p_to_c.fk_product_id', '=', 'products.id');
                $query->leftJoin('category_to_tags as c_to_t', 'c_to_t.fk_tags_id', '=', 'p_to_c.fk_tags_id');
                $query->whereIn('category_relations.cat_id', $category_id);
                $query->where('category_relations.relation_type', 'product');
                
                
            }

            //Price Range Filter
            if (!empty($request->price_range)) 
            {
                $key .= '_' . $request->price_range;
                $price_range = explode(";", $request->price_range);
                $query->whereBetween('products.price', [$price_range[0], $price_range[1]]);
            }


            if ($request->sort) 
            {
                $sort = $request->sort;
                $key .= '_' . $sort;
                if ($sort == 1) 
                {
                    $query->orderBy('products.created_at', 'desc');
                } 
                elseif ($sort == 2) 
                {
                    $query->orderBy('products.price', 'asc');
                } 
                elseif ($sort == 3) 
                {
                    $query->orderBy('products.price', 'desc');
                } 
                elseif ($sort == 4) 
                {
                    $query->leftJoin('order_to_store', 'products.id', '=', 'order_to_store.product_id')
                            ->groupBy('products.id')
                            ->orderBy('ids', 'desc');
                    $order_ids = ",count(order_to_store.product_id) as ids";
                }
            } 
            else if ($segment1 == "category") 
            {
                $key .= '_orderbyidss';
                $query->orderBy('products.id', 'desc');
            } 
            else 
            {
                $key .= '_productid';
                if ($segment1 == "store") 
                {
                    if($store_data->product_order_by == 1)
                    {
                        $query->orderBy('products.id', 'desc');
                    }
                    elseif($store_data->product_order_by == 2)
                    {
                        $query->orderBy('products.price', 'DESC');
                    }
                    elseif($store_data->product_order_by == 3)
                    {
                        $query->orderBy('products.price', 'ASC');
                    }
                    elseif($store_data->product_order_by == 5)
                    {
                        $query->orderBy('products.name', 'ASC');
                    }
                    elseif($store_data->product_order_by == 6)
                    {
                        $query->orderBy('products.name', 'DESC');
                    }
                    elseif($store_data->product_order_by == 7)
                    {
                        $query->leftJoin('order_to_store', 'products.id', '=', 'order_to_store.product_id')
                                ->groupBy('products.id')
                                ->orderBy('ids', 'desc');
                        $order_ids = ",count(order_to_store.product_id) as ids";
                    }
                    else
                    {
                        $cat_id = $store_data->product_order_by - 100;
                        $query->leftJoin('category_relations', 'products.id', '=', 'category_relations.entity_id');
                        $query->where([
                            ['category_relations.relation_type', '=', "product"],
                            ['category_relations.deleted_at', null]
                        ]);
                        $query->orderByRaw('FIELD(category_relations.cat_id, "'.$cat_id.'") DESC');
                    }
                }
                else
                {
                    $query->orderBy('products.id', 'desc');
                }
            }
            $query = $query->select(DB::raw('DISTINCT(products.id), products.name,products.short_description,products.sku, products.price, products.sale_price, products.description,products.slug, products.item_fabric, products.custom_sizes, products.category_fields, ss.offline' . $order_ids . ''));
            
            $products = $query->distinct()->paginate(10);

            return response()->json(['data' => $products, 'status_code' => 200, 'status' => true], 200);
        } 
        catch (Exception $e) 
        {
            return Response::json(['status_code' => 500, 'error' => 'There is something wrong', 'status' => false], 500);
        }
    }

     /* Recent Product*/
    public function recent($language_id)
    {
        try 
        {
            $query = DB::table('products');
            if ($language_id && $language_id == 'ar') 
            {
                $query->where('lang', $language_id);
            }
            if($language_id && $language_id == 'en')
            {
                $query->where('lang', $language_id);
            }
            
            $query->where('status', 1);
            $query->where('hide_product', 1);
            $query->groupBy('store_id');
            $query->orderBy('id', 'DESC');
            $query->limit(12);
            $query->select('id','name', 'short_description','sku', 'price','sale_price','description', 'is_featured','quantity', 'slug', 'no_of_days');
            $recent_products = $query->get();
            if(count($recent_products) == 0)
            {
                return response()->json(['data' => 'Record Not Found', 'status_code' => 404, 'status' => flase],404); 
            }

            return response()->json(['data' => $recent_products, 'status_code' => 200, 'status' => true],200);   
        } 
        catch (Exception $e) 
        {
            return Response::json(['error' => 'There is something wrong', 'status_code' => 500, 'status' => false], 500);
        }
    }

    public function popular_products($language_id)
    {
        try
        {
            $query = "SELECT count(os.id) as total_sell,os.product_id,p.*,p.`name`,p.slug,p.id 
            FROM `order_to_store` os 
            LEFT JOIN products p ON p.id = os.product_id
            LEFT JOIn orders o ON o.id =os.order_id
            WHERE o.status != 'Rejected' AND o.status != 'rejected' AND o.status != 'unPaid' AND o.status != 'in_progress' AND o.status != 'on_hold' AND o.status != 'cancelled' 
            AND o.status != 'declined'
            AND p.status = 1 
            AND p.deleted_at is NULL 
            AND hide_product = 1
            GROUP BY os.product_id ORDER BY total_sell DESC  LIMIT 12";
            $p_products = DB::select($query);
            $pro = array();
            if($language_id != 'en')
            {

                foreach ($p_products as $p_product)
                {
                    if($p_product->lang != 'en')
                    {
                        $pro[]  = $p_product;
                    }
                    else
                    {
                        $query = DB::table('products');
                        $query->select(DB::raw('products.*,products.`name`,products.slug,products.id'));
                        $query->leftJoin('stores as ss', 'products.store_id', '=', 'ss.id');
                        $query->where('products.lang_content_type', $p_product->id);
                        $query->where('lang', 'ar');
                        $p = $query->first();
                        if($p && count($p) > 0)
                        {
                            $pro[] = $p;
                        }
                    }
                }
                $popular_products = (Object) $pro;
            }
            else
            {
                $popular_products = $p_products;
            }
            return response()->json(['data' => $popular_products, 'status_code' => 200, 'status' => true],200);   
        } 
        catch (Exception $e) 
        {
            return Response::json(['error' => 'There is something wrong', 'status_code' => 500, 'status' => false], 500);
        }
    }

    
}
