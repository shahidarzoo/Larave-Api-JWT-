<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Products;
use DB;
use Response;
use App\Models\Category;
use App\CustomMeasurements;
use Illuminate\Session\Store;
use App\Models\CategoryRelation;
use App\Stores;
use App\ProductVariations;
use App\Tags;

class ProductController extends Controller
{
	// Product Details
    public function index(Request $request, $language_id = null)
    {
    	try 
    	{
            $page_id = '';
            $category_obj = '';
            $order_ids = "";
            $cache_enabled = config('cache.enabled_listing_item');
            $cache_duration = config('cache.duration');
            $cache_prefix = config('cache.cache_prefix');
            $cache_enabled = false;
            $key = 'category_products_load';
            if ($request->segment(1) != NULL) 
            {
                $key .= '_' . $request->segment(1);
            }
            if ($request->segment(2) != NULL) 
            {
                $key .= '_' . $request->segment(2);
            }

            if ($_GET['page'] != NULL) 
            {
                $key .= '_' . $_GET['page'];
            }

            $query = DB::table('products');
            $query->where(["products.status" => 1, "products.hide_product" => 1, 'products.deleted_at' => null]);
            $query->leftJoin('stores as ss', 'products.store_id', '=', 'ss.id');

            if ($language_id && $language_id == 'ar') 
            {
                $query->where('products.lang', $language_id);
            }
            if($language_id && $language_id == 'en')
            {
                $query->where('products.lang', $language_id);
            }
            /* To fetch images from product*/
            $query->leftJoin('product_images as pimg', 'products.id', '=', 'pimg.product_id');
            $query->where('pimg.is_featured', 1);


            //apply store filter
            $store_data = "";
            $segment1 = $request->s;
            if ($segment1 == "search") 
            {
                $page_id = 'search';

                $key .= '_' . $request->s;
                $query_string = $request->s;

                $category_obj = DB::table('categories')
                                ->where("name", 'like', "%{$query_string}%")
                                ->where(["status" => 1, "parent_id" => 0, 'deleted_at' => null])
                                ->take(1)
                                ->first();
                $search_cat_id = $category_obj->id;


                $color_obj = DB::table('colours')
                            ->where("name", 'like', "%{$query_string}%")
                            ->take(1)
                            ->first();
                $color_id = $color_obj->id;
                $color_condition = '';
                if ($color_id) 
                {
                    $query->Join('product_variations as pv', 'products.id', '=', 'pv.product_id');
                    $color_condition = true;
                }

                $size_obj = DB::table('sizes')
                            ->where("name", 'like', "%{$query_string}%")
                            ->take(1)
                            ->first();
                $size_id = $size_obj->id;
                $size_condition = '';
                if ($size_id) 
                {
                    $query->Join('product_variations', 'products.id', '=', 'product_variations.product_id');
                    $size_condition = true;
                }

                $store_obj = DB::table('stores')
                            ->where("title", 'like', "%{$query_string}%")
                            ->take(1)
                            ->first();
                $store_id = $store_obj->id;
                $store_condition = '';
                if ($store_id) 
                {
                    $store_condition = true;
                }


                if ($search_cat_id) 
                {
                    $category_id = $search_cat_id;
                    $query->join('category_relations', 'products.id', '=', 'category_relations.entity_id');
                    $query->leftJoin('product_to_tags as p_to_c', 'p_to_c.fk_product_id', '=', 'products.id');
                    $query->leftJoin('category_to_tags as c_to_t', 'c_to_t.fk_tags_id', '=', 'p_to_c.fk_tags_id');
                    $query->where(function ($query) use ($category_id, $query_string) 
                    {
                        $query->orWhere([
                            ['category_relations.cat_id', '=', $category_id],
                            ['category_relations.relation_type', '=', "product"],
                            ['category_relations.deleted_at', null]
                        ])->orWhere('c_to_t.fk_category_id', '=', $category_id)
                        ->orWhere('products.name', 'like', "%{$query_string}%")
                        ->orWhere('products.short_description', 'like', "%{$query_string}%");
                    });
                } 
                else 
                {
                    $query->where(function ($query) use ($color_condition, $size_condition, $store_condition, $color_id, $size_id, $store_id, $query_string) 
                    {
                        $query->where('products.name', 'like', "%{$query_string}%")
                                ->orWhere('products.short_description', 'like', "%{$query_string}%");
                        if ($color_condition) 
                        {
                            $query->orWhere('pv.color_id', $color_id);
                        }
                        if ($size_condition) 
                        {
                            $query->orWhere('product_variations.size_id', $size_id);
                        }
                        if ($store_condition) 
                        {
                            $query->orWhere('products.store_id', $store_id);
                        }
                    });
                }
            }

            /* End search filter */
            /*Filter Recent*/
            if ($request->recent) 
            {
                $page_id = 'recent_product';
                $query->orderBy('products.created_at', 'DESC');
            }
            /*End Recent filter */

            /*Filter Tranding*/
            if ($request->trending) 
            {
                $page_id = 'trending_product';
                $query->leftJoin('order_to_store', 'products.id', '=', 'order_to_store.product_id')
                        ->groupBy('products.id')
                        ->orderBy('ids', 'desc');
                $order_ids = ",count(order_to_store.product_id) as ids";
            }
            /*End Filter Tranding*/

            //apply color filter
            if (is_array($request->colors) && count($request->colors) >= 1) 
            {
                $key .= '_' . json_encode($request->colors);
                $query->Join('product_variations as pv', 'products.id', '=', 'pv.product_id');
                $query->whereIn('pv.color_id', $request->colors);
            }

            //apply size filter
            if (is_array($request->sizes) && count($request->sizes) >= 1) 
            {
                $key .= '_' . json_encode($request->sizes);
                $query->Join('product_variations', 'products.id', '=', 'product_variations.product_id');
                $query->whereIn('product_variations.size_id', $request->sizes);
            }
            if ($request->fabric) 
            {
                $fabric = $request->fabric;
                $query->where('products.item_fabric', 'like', "%$fabric%");
            }

            //apply category filter
            $category_id = "";
            $filter_type_text = "";
            $filters = array();
            /*Filters Category */
            if ($segment1 == "category") 
            {
                $page_id = 'category';
                $alias = $request->segment(2);
                
                    $category_obj = Category::where("alias", $alias)->take(1)->first();
                    $filter_type_text = $category_obj->filter_type;
                    $category_id = $category_obj->id;
                    //dd( $category_obj->filter_type);
                if (empty($category_id) && !is_numeric($category_id)) 
                {
                    abort(404);
                }
                $query->join('category_relations', 'products.id', '=', 'category_relations.entity_id');
                $query->leftJoin('product_to_tags as p_to_c', 'p_to_c.fk_product_id', '=', 'products.id');
                $query->leftJoin('category_to_tags as c_to_t', 'c_to_t.fk_tags_id', '=', 'p_to_c.fk_tags_id');
                $query->where(function ($query) use ($category_id) 
                {
                    $query->where([
                        ['category_relations.cat_id', '=', $category_id],
                        ['category_relations.relation_type', '=', "product"],
                        ['category_relations.deleted_at', null]
                    ])->orWhere('c_to_t.fk_category_id', '=', $category_id);
                });

                $tags_filters = Tags::select("tags.id", "tags.title")
                                ->join('category_to_tags as tag', 'tags.id', '=', 'tag.fk_tags_id')
                                ->where("tag.fk_category_id", $category_id)
                                ->orderBy('tags.title', 'ASC')
                                ->get();
                if (!empty($request->tags)) 
                {
                    $key .= '_tag' . $request->tags;
                    $query->whereIn('c_to_t.fk_tags_id', $request->tags);
                }

                $filters = Category::where("id", $category_id)
                            ->take(1)
                            ->value('filters');
                $filters = json_decode($filters);
            }
            /* End Category Filter */

            //apply store filter
            $store_data = "";
            if ($segment1 == "store") 
            {
                $page_id = 'store';
                $alias = $request->segment(2);

                if ($cache_enabled) 
                {
                    $key3 = $cache_prefix . '_get_store_info_by_alias_' . $alias;
                    $store_data = Cache::remember($key3, $cache_duration, function () use ($alias) 
                    {
                        return DB::table("stores")->where([
                                ['slug', '=', $alias],
                                ['status', '=', 1],
                                ['deleted_at', null]
                                ])->take(1)
                                ->first();
                        });
                } 
                else 
                {
                    $store_data = DB::table("stores")->where([
                                ['slug', '=', $alias],
                                ['status', '=', 1],
                                ['deleted_at', null]
                            ])->take(1)->first();
                }
                $store_id = $store_data->id;
                if (empty($store_id) && !is_numeric($store_id)) 
                {
                    abort(404);
                }
                $query->where("products.store_id", $store_id);
            }
            /*End Store Filter */

            //apply ajax brand/store filter
            if (is_array($request->brands) && count($request->brands) >= 1) 
            {
                $request->brands;
                $alias = $request->segment(2);
                $query->join('stores', 'products.store_id', '=', 'stores.id')
                        ->whereIn('stores.id', $request->brands);

                $category_ids = CategoryRelation::whereIn('entity_id', $request->brands)
                                ->where('relation_type', 'store')->pluck('cat_id');
                               
                $cat_ids = [];
                foreach ($category_ids as $key => $cat_val) 
                {
                    array_push($cat_ids, $cat_val);
                }
                $query->join('category_relations as cr', 'products.id', '=', 'cr.entity_id')
                        ->where(function ($query) use ($cat_ids) 
                        {
                            $query->where(function ($query) use ($cat_ids) 
                            {
                                $query->whereIn('cr.cat_id', $cat_ids)
                                ->where('cr.relation_type', "product")
                                ->where('cr.deleted_at', null);
                            })->orWhereIn('c_to_t.fk_category_id', $cat_ids);
                        });
            }
            
            
               //apply ajax brand/store filter
            if (is_array($request->brands_new) && count($request->brands_new) >= 1) 
            {

                $request->brands_new;
                $alias = $request->segment(2);
                $query->join('stores', 'products.store_id', '=', 'stores.id')
                        ->whereIn('stores.id', $request->brands_new);

                $category_ids = CategoryRelation::whereIn('entity_id', $request->brands_new)
                                ->where('relation_type', 'store')->pluck('cat_id');
                               
                $cat_ids = [];
                foreach ($category_ids as $key => $cat_val) 
                {
                    array_push($cat_ids, $cat_val);
                }
                $query->join('category_relations as cr', 'products.id', '=', 'cr.entity_id')
                        ->where(function ($query) use ($cat_ids) 
                        {
                            $query->where(function ($query) use ($cat_ids) 
                            {
                                $query->whereIn('cr.cat_id', $cat_ids)
                                ->where('cr.relation_type', "product")
                                ->where('cr.deleted_at', null);
                            });
                        });
            }
            
               //Category Filter
            if (is_array($request->category_id2) && count($request->category_id2) >= 1) 
            {

                $category_id = $request->category_id2;           
                $alias = $request->segment(2);

                $query->join('category_relations', 'products.id', '=', 'category_relations.entity_id');
                $query->leftJoin('product_to_tags as p_to_c', 'p_to_c.fk_product_id', '=', 'products.id');
                $query->leftJoin('category_to_tags as c_to_t', 'c_to_t.fk_tags_id', '=', 'p_to_c.fk_tags_id');
                $query->whereIn('category_relations.cat_id', $category_id);
                $query->where('category_relations.relation_type', 'product');
                
                
            }


            //Price Range Filter
            if (!empty($request->price_range)) 
            {
                $key .= '_' . $request->price_range;
                $price_range = explode(";", $request->price_range);
                $query->whereBetween('products.price', [$price_range[0], $price_range[1]]);
            }
            if ($request->sort) 
            {
                $sort = $request->sort;
                $key .= '_' . $sort;
                if ($sort == 1) 
                {
                    $query->orderBy('products.created_at', 'desc');
                } 
                elseif ($sort == 2) 
                {
                    $query->orderBy('products.price', 'asc');
                } 
                elseif ($sort == 3) 
                {
                    $query->orderBy('products.price', 'desc');
                } 
                elseif ($sort == 4) 
                {
                    $query->leftJoin('order_to_store', 'products.id', '=', 'order_to_store.product_id')
                            ->groupBy('products.id')
                            ->orderBy('ids', 'desc');
                    $order_ids = ",count(order_to_store.product_id) as ids";
                }
            } 
            else if ($segment1 == "category") 
            {
                $key .= '_orderbyidss';
                $query->orderBy('products.id', 'desc');
            } 
            else 
            {
                $key .= '_productid';
                if ($segment1 == "store") 
                {
                    if($store_data->product_order_by == 1)
                    {
                        $query->orderBy('products.id', 'desc');
                    }
                    elseif($store_data->product_order_by == 2)
                    {
                        $query->orderBy('products.price', 'DESC');
                    }
                    elseif($store_data->product_order_by == 3)
                    {
                        $query->orderBy('products.price', 'ASC');
                    }
                    elseif($store_data->product_order_by == 5)
                    {
                        $query->orderBy('products.name', 'ASC');
                    }
                    elseif($store_data->product_order_by == 6)
                    {
                        $query->orderBy('products.name', 'DESC');
                    }
                    elseif($store_data->product_order_by == 7)
                    {
                        $query->leftJoin('order_to_store', 'products.id', '=', 'order_to_store.product_id')
                                ->groupBy('products.id')
                                ->orderBy('ids', 'desc');
                        $order_ids = ",count(order_to_store.product_id) as ids";
                    }
                    else
                    {
                        $cat_id = $store_data->product_order_by - 100;
                        $query->leftJoin('category_relations', 'products.id', '=', 'category_relations.entity_id');
                        $query->where([
                            ['category_relations.relation_type', '=', "product"],
                            ['category_relations.deleted_at', null]
                        ]);
                        $query->orderByRaw('FIELD(category_relations.cat_id, "'.$cat_id.'") DESC');
                    }
                }
                else
                {
                    $query->orderBy('products.id', 'desc');
                } 
            }

            $query->distinct('products.id');

            //$query = $query->select(DB::raw('DISTINCT(products.id), "products.id", "products.name", "products.short_description", "products.price", "products.sale_price", ss.offline' . $order_ids . ''));

            $query->select(['products.id','name','short_description','products.price','products.sale_price','products.is_featured','products.quantity', 'products.slug','custom_sizes','custom_sizes','url','logo_path','facebook_handle','twitter_handle','linkedin_handle','instagram_handle','ss.title as store_name','pimg.image_path as product_image']);
            
            $products = $query->distinct()->paginate(10);
            /* check product exist or not */
    		if(count($products) == 0)
    		{
    			return response()->json(['status_code' => 404, 'error' => 'Records not found', 'status' => false], 404);
    		}
    		return response()->json(['data'=> $products, 'status_code' => 200, 'status' => true], 200);
    	} 
    	catch (Exception $e) 
    	{
    		return Response::json(['status_code' => 500, 'error' => 'There is an error', 'status' => false], 500);	
    	}
    }
 	// Product Base on Category
    public function category_products($alias, $language_id) 
    {
        try 
        {
            $category_obj = '';
            $get_active_language_id = $language_id;

            $query = DB::table('products');
            $query->where(["products.status" => 1, "products.hide_product" => 1, 'products.deleted_at' => null]);
            $query->leftJoin('stores as ss', 'products.store_id', '=', 'ss.id');
            $query->leftJoin('product_images as im', 'products.id', '=', 'im.product_id');


            //apply category filter
            $category_id = "";

            $category_obj = Category::where("alias", $alias)->take(1)->first();
            $category_id = $category_obj->id;
            //dd( $category_obj->filter_type);
            if (empty($category_id) && !is_numeric($category_id)) 
            {
                abort(404);
            }
            $query->join('category_relations', 'products.id', '=', 'category_relations.entity_id');
            $query->leftJoin('product_to_tags as p_to_c', 'p_to_c.fk_product_id', '=', 'products.id');
            $query->leftJoin('category_to_tags as c_to_t', 'c_to_t.fk_tags_id', '=', 'p_to_c.fk_tags_id');
            $query->where(function ($query) use ($category_id) {
                $query->where([
                    ['category_relations.cat_id', '=', $category_id],
                    ['category_relations.relation_type', '=', "product"],
                    ['category_relations.deleted_at', null]
                ])->orWhere('c_to_t.fk_category_id', '=', $category_id);
            });

            $query->orderBy('products.id', 'desc');


            $query->where('products.lang', $get_active_language_id);
            $query->where('im.is_featured', 1);
            if($get_active_language_id && $get_active_language_id != 'en')
            {
                $store_title = ' ,IFNULL(ss.ar_title, ss.title) AS `store_name`';
            }
            else
            {
                $store_title = ' ,ss.title AS `store_name`';
            }
            $query = $query->select(DB::raw('DISTINCT(products.id), products.name, products.short_description, products.price, products.sale_price, products.description, products.slug, products.no_of_days, products.item_fabric,  im.thumbnail_path as image, ss.offline,ss.offline_message'.$store_title));
            
            $products = $query->distinct()->paginate(10, ['products.id']);
            $pages = "available";
            $next_page = 10000000;
            if ($products->lastPage() == $products->currentPage() || $products->hasMorePages() == false) 
            {
                $pages = "last";
            } 
            else 
            {
                $next_page = $products->currentPage() + 1;
            }
            if (count($products) == 0) 
            {
                return response()->json(['status_code' => 404, 'error' => 'Records not fount', 'status' => false], 404);
            }


            /* colors for sidebar */
           /* $colours = array();
            if(request()->segment(2) == "product-category")
            {
                $query = DB::table('product_variations as pv');
                if($get_active_language_id && $get_active_language_id != 'en')
                {
                    $query->select(DB::raw('DISTINCT(color_id),c.id,IFNULL(c.ar_name, c.name) AS `name`'));
                }
                else
                {
                    $query->select(DB::raw('DISTINCT(color_id),c.id,c.name AS `name`'));
                }
                $query->leftJoin('products', 'pv.product_id', '=', 'products.id')
                ->leftJoin('product_to_tags as p_to_c', 'p_to_c.fk_product_id', '=', 'products.id')
                ->leftJoin('category_to_tags as c_to_t', 'c_to_t.fk_tags_id', '=', 'p_to_c.fk_tags_id')
                ->leftJoin('colours as c', 'pv.color_id', '=', 'c.id')
                ->where([
                    ['products.deleted_at', '=', null],
                    ['products.hide_product', '=', 1],
                    ['products.status', '=', 1],
                ]);
                $colours = $query->where([
                    ['pv.deleted_at', null]
                ])->where([
                    ['c.name','!=' , null]
                ])->orderBy('c.name', 'ASC')
                ->get();
            }*/
            /* End colors for sidebar */
            /*$data = array(
                'product' => $products,
                'color' => $colours
            );*/
            /*$products_fabric = array();
            $item = array(); 
            if (count($products) >= 1) 
            {
                foreach ($products as $product) 
                {
                    $p_f = $product->item_fabric;
                    $products_fabric[$p_f] = $p_f;
                } 
            }
            if($products_fabric && count($products_fabric) > 0)
            {
                 foreach ($products_fabric as $fab_key => $fab)
                 {
                    $item = $fab;
                 }
            }             
            $data = array(
                'products' => $products,
                'item_fabric' => $item
            );*/
            return response()->json(['data' => $products, 'status_code' => 200, 'status' => true], 200);
        } catch (Exception $ex) {
            return Response::json(['status_code' => 500, 'error' => 'There is some thing wrong', 'status' => false], 500);
        }
     }

    // single product with slug
    public function show($slug, $language_id) 
    {
        try 
        {
            $query = DB::table('products');
            if ($language_id && $language_id == 'ar') 
            {
                $query->select(DB::raw('stores.slug,IFNULL(stores.ar_title, stores.title) AS `title`'));
            }
            if($language_id && $language_id == 'en')
            {
                $query->select('stores.slug','stores.title');
            }
            $query->whereNull('products.deleted_at');
            $query->leftJoin('stores', 'products.store_id', '=', 'stores.id');
            $query->where('products.slug', $slug);
            $query->groupBy('products.store_id');
            $query->where('products.lang', $language_id);
            $query->select('products.id', 'products.name', 'products.short_description', 'products.price', 'products.sale_price', 'products.description', 'products.slug', 'products.no_of_days', 'products.item_fabric','store_id','category_fields');
            $product = $query->first();

            $new_category_fields = array();
            if (isset($product->category_fields) && !empty($product->category_fields)) 
            {
                $category_fields = isset($product->category_fields) ? json_decode($product->category_fields) : '';
                foreach ($category_fields as $key => $item) 
                {

                    $field_data = mh_get_row_by_where('category_fields', array('name' => $key));
                    if (isset($language_id) && $language_id != 'en') 
                    {
                        $key_name = $field_data->ar_label;
                    } 
                    elseif (isset($language_id) && $language_id == 'en') 
                    {
                        $key_name = $field_data->label;
                    } 
                    else 
                    {
                        $key_name = $key;
                    }
                    if ($category_fields->sheila_included == 'Yes' || $category_fields->sheila_included == 'yes') 
                    {
                        $new_category_fields[$key_name] = $item;
                    } 
                    else 
                    {
                        if ($key != 'sheila_type' && $key != 'sheila_fabric' && $key != 'sheila_size') 
                        {
                            $new_category_fields[$key_name] = $item;
                        }
                    }
                }
            }
            $product->category_fields = (object)$new_category_fields;
            
            $product_images = DB::table('product_images')
                                ->where(['product_id' => $product->id, "deleted_at" => null])
                                ->where([["thumbnail_path", '!=', null]])
                                ->orderBy('is_featured','DESC')
                                ->select(DB::raw('IFNULL(thumbnail_path, image_path) AS `image`'))
                                ->get();
            $product->store = $this->get_store($product->store_id, $language_id);
            
            $product->images = $product_images;
            
            if (count($product) == 0) 
            {
                return response()->json(['status_code' => 404, 'error' => 'Record not found', 'status' => false], 404);
            }
            return response()->json(['data' => $product, 'status_code' => 200, 'status' => true], 200);
        } 
        catch (Exception $e) 
        {
            return Response::json(['status_code' => 500, 'error' => 'There is some thing wrong', 'status' => false], 500);
        }
    }

    public function get_store($store_id, $language_id)
    {
        $query = DB::table('stores');
        if ($language_id && $language_id == 'ar') 
        {
            $query->select(DB::raw('logo_path,description,offline_status,slug,IFNULL(ar_title, title) AS `title`'));
        }
        if($language_id && $language_id == 'en')
        {
            $query->select('logo_path','description','offline_status','slug','title');
        }
        
        $query->where('id', $store_id);
        $data = $query->first();
        return $data;
    }

    public function search(Request $request, $language_id)
    {
        try 
        {
            $page_id = '';
            $category_obj = '';

            $order_ids = "";
            $cache_enabled = config('cache.enabled_listing_item');
            $cache_duration = config('cache.duration');
            $cache_prefix = config('cache.cache_prefix');
            $cache_enabled = false;
            $segment1 = $request->segment;
            $segment_value = $request->segment_value;
            $key = 'category_products_load';
            if ($segment_value != NULL) 
            {
                $key .= '_' . $segment1;
            }
            if ($request->segment(3) != NULL) 
            {
                $key .= '_' . $segment_value;
            }

            if ($_GET['page'] != NULL) 
            {
                $key .= '_' . $_GET['page'];
            }
            
            
            
            if($segment1 == '')
            {
                return response()->json(['Segment is required', 'status_code' => 400, 'status' => false], 400);
            }
            if($segment_value == '')
            {
                return response()->json(['Segment value is required', 'status_code' => 400, 'status' => false], 400);
            }
            
            
            
            $query = DB::table('products');
            $query->where(["products.status" => 1, "products.hide_product" => 1, 'products.deleted_at' => null]);
            if($language_id && $language_id == 'ar')
            {
                 $query->where('lang', $language_id);
            }
            if($language_id && $language_id == 'en')
            {
                 $query->where('lang', $language_id);
            }
            $query->leftJoin('stores as ss', 'products.store_id', '=', 'ss.id');
            
            $store_data = "";
            

            if($segment1 == 'search')
            {
            
                $key .= '_' . $segment_value;
                $query_string = $segment_value;

                $category_obj = DB::table('categories')->where("name", 'like', "%{$query_string}%")->where(["status" => 1, "parent_id" => 0, 'deleted_at' => null])->take(1)->first();
                $search_cat_id = $category_obj->id;


                $color_obj = DB::table('colours')->where("name", 'like', "%{$query_string}%")->take(1)->first();
                $color_id = $color_obj->id;

                $color_condition = '';
                if ($color_id) 
                {
                    $query->Join('product_variations as pv', 'products.id', '=', 'pv.product_id');
                    $color_condition = true;
                }

                $size_obj = DB::table('sizes')->where("name", 'like', "%{$query_string}%")->take(1)->first();
                $size_id = $size_obj->id;
                $size_condition = '';
                if ($size_id) 
                {
                    $query->Join('product_variations', 'products.id', '=', 'product_variations.product_id');
                    $size_condition = true;
                }

                $store_obj = DB::table('stores')->where("title", 'like', "%{$query_string}%")->take(1)->first();
                $store_id = $store_obj->id;

                $store_condition = '';
                if ($store_id) 
                {
                    $store_condition = true;
                }


                if ($search_cat_id) 
                {
                    $category_id = $search_cat_id;
                    $query->join('category_relations', 'products.id', '=', 'category_relations.entity_id');
                    $query->leftJoin('product_to_tags as p_to_c', 'p_to_c.fk_product_id', '=', 'products.id');
                    $query->leftJoin('category_to_tags as c_to_t', 'c_to_t.fk_tags_id', '=', 'p_to_c.fk_tags_id');
                    $query->where(function ($query) use ($category_id, $query_string) 
                    {
                        $query->orWhere([
                            ['category_relations.cat_id', '=', $category_id],
                            ['category_relations.relation_type', '=', "product"],
                            ['category_relations.deleted_at', null]
                        ])->orWhere('c_to_t.fk_category_id', '=', $category_id)
                        ->orWhere('products.name', 'like', "%{$query_string}%")
                        ->orWhere('products.short_description', 'like', "%{$query_string}%");
                    });
                    
                }
                else
                {
                    $query->where(function ($query) use ($color_condition, $size_condition, $store_condition, $color_id, $size_id, $store_id, $query_string) 
                    {
                        $query->where('products.name', 'like', "%{$query_string}%")
                                ->orWhere('products.short_description', 'like', "%{$query_string}%");
                        if ($color_condition) 
                        {
                            $query->orWhere('pv.color_id', $color_id);
                        }
                        if ($size_condition) 
                        {
                            $query->orWhere('product_variations.size_id', $size_id);
                        }
                        if ($store_condition) 
                        {
                            $query->orWhere('products.store_id', $store_id);
                        }
                    });
                }
            }
            if ($request->segment(3) != NULL && $segment_value == "recent") 
            {
                $query->orderBy('products.created_at', 'DESC');
            }
            if ($request->segment(3) != NULL && $segment_value == "trending") 
            {
                $query->leftJoin('order_to_store', 'products.id', '=', 'order_to_store.product_id')
                    ->groupBy('products.id')
                    ->orderBy('ids', 'desc');
                $order_ids = ",count(order_to_store.product_id) as ids";
            }

            //apply color filter
            if (is_array($request->colors) && count($request->colors) >= 1) 
            {
                $key .= '_' . json_encode($request->colors);
                $query->Join('product_variations as pv', 'products.id', '=', 'pv.product_id');
                $query->whereIn('pv.color_id', $request->colors);
            }
            //apply size filter
            if (is_array($request->sizes) && count($request->sizes) >= 1) 
            {
                $key .= '_' . json_encode($request->sizes);
                $query->Join('product_variations', 'products.id', '=', 'product_variations.product_id');
                $query->whereIn('product_variations.size_id', $request->sizes);
            }
            if($request->fabric) 
            {
                $fabric = $request->fabric;
                $query->where('products.item_fabric', 'like', "%{$fabric}%");
            }

            //apply category filter
            $category_id = "";
            $filter_type_text = "";
            $filters = array();
            if ($segment1 == "category") 
            {
                $alias = $segment_value;
                
                    $category_obj = Category::where("alias", $alias)->take(1)->first();
                    $filter_type_text = $category_obj->filter_type;
                    $category_id = $category_obj->id;
                    //dd( $category_obj->filter_type);
                if (empty($category_id) && !is_numeric($category_id)) 
                {
                    return response()->json(['Category not found', 'status_code' => 400, 'status' => false], 400);
                }
                $query->join('category_relations', 'products.id', '=', 'category_relations.entity_id');
                $query->leftJoin('product_to_tags as p_to_c', 'p_to_c.fk_product_id', '=', 'products.id');
                $query->leftJoin('category_to_tags as c_to_t', 'c_to_t.fk_tags_id', '=', 'p_to_c.fk_tags_id');
                $query->where(function ($query) use ($category_id) 
                {
                    $query->where([
                        ['category_relations.cat_id', '=', $category_id],
                        ['category_relations.relation_type', '=', "product"],
                        ['category_relations.deleted_at', null]
                    ])->orWhere('c_to_t.fk_category_id', '=', $category_id);
                });

                $tags_filters = Tags::select("tags.id", "tags.title")
                                ->join('category_to_tags as tag', 'tags.id', '=', 'tag.fk_tags_id')
                                ->where("tag.fk_category_id", $category_id)
                                ->orderBy('tags.title', 'ASC')
                                ->get();
                if (!empty($request->tags)) 
                {
                    $key .= '_tag' . $request->tags;
                    $query->whereIn('c_to_t.fk_tags_id', $request->tags);
                }

                $filters = Category::where("id", $category_id)
                            ->take(1)
                            ->value('filters');
                $filters = json_decode($filters);
            }
            //apply store filter
            $store_data = "";
            if ($segment1 == "store") 
            {
                $alias = $segment_value;

                if ($cache_enabled) 
                {
                    $key3 = $cache_prefix . '_get_store_info_by_alias_' . $alias;
                    $store_data = Cache::remember($key3, $cache_duration, function () use ($alias) 
                    {
                        return DB::table("stores")->where([
                            ['slug', '=', $alias],
                            ['status', '=', 1],
                            ['deleted_at', null]
                        ])->take(1)
                        ->first();
                        });
                } 
                else 
                {
                    $store_data = DB::table("stores")->where([
                            ['slug', '=', $alias],
                            ['status', '=', 1],
                            ['deleted_at', null]
                        ])->take(1)
                        ->first();
                }
                $store_id = $store_data->id;
                if($store_id){
                    return response()->json(['Store not found', 'status_code' => 400, 'status' => false], 400);
                }
                if (empty($store_id) && !is_numeric($store_id)) 
                {
                    return response()->json(['Category not found', 'status_code' => 400, 'status' => false], 400);
                }
                $query->where("products.store_id", $store_id);
            }
            //apply ajax brand/store filter
            if (is_array($request->brands) && count($request->brands) >= 1) 
            {
                $request->brands;
                $alias = $segment_value;
                $query->join('stores', 'products.store_id', '=', 'stores.id')
                        ->whereIn('stores.id', $request->brands);

                $category_ids = CategoryRelation::whereIn('entity_id', $request->brands)
                                ->where('relation_type', 'store')
                                ->pluck('cat_id');
                               
                $cat_ids = [];
                foreach ($category_ids as $key => $cat_val) 
                {
                    array_push($cat_ids, $cat_val);
                }
                $query->join('category_relations as cr', 'products.id', '=', 'cr.entity_id')
                        ->where(function ($query) use ($cat_ids) {
                            $query->where(function ($query) use ($cat_ids) {
                                $query->whereIn('cr.cat_id', $cat_ids)
                                ->where('cr.relation_type', "product")
                                ->where('cr.deleted_at', null);
                            })->orWhereIn('c_to_t.fk_category_id', $cat_ids);
                        });
            }
            
            
               //Category Filter
            if (is_array($request->category_id2) && count($request->category_id2) >= 1) 
            {

                $category_id = $request->category_id2;           
                $alias = $segment_value;

                $query->join('category_relations', 'products.id', '=', 'category_relations.entity_id');
                $query->leftJoin('product_to_tags as p_to_c', 'p_to_c.fk_product_id', '=', 'products.id');
                $query->leftJoin('category_to_tags as c_to_t', 'c_to_t.fk_tags_id', '=', 'p_to_c.fk_tags_id');
                $query->whereIn('category_relations.cat_id', $category_id);
                $query->where('category_relations.relation_type', 'product');
                
                
            }

            //Price Range Filter
            if (!empty($request->price_range)) 
            {
                $key .= '_' . $request->price_range;
                $price_range = explode(";", $request->price_range);
                $query->whereBetween('products.price', [$price_range[0], $price_range[1]]);
            }


            if ($request->sort) 
            {
                $sort = $request->sort;
                $key .= '_' . $sort;
                if ($sort == 1) 
                {
                    $query->orderBy('products.created_at', 'desc');
                } 
                elseif ($sort == 2) 
                {
                    $query->orderBy('products.price', 'asc');
                } 
                elseif ($sort == 3) 
                {
                    $query->orderBy('products.price', 'desc');
                } 
                elseif ($sort == 4) 
                {
                    $query->leftJoin('order_to_store', 'products.id', '=', 'order_to_store.product_id')
                            ->groupBy('products.id')
                            ->orderBy('ids', 'desc');
                    $order_ids = ",count(order_to_store.product_id) as ids";
                }
            } 
            else if ($segment1 == "category") 
            {
                $key .= '_orderbyidss';
                $query->orderBy('products.id', 'desc');
            } 
            else 
            {
                $key .= '_productid';
                if ($segment1 == "store") 
                {
                    if($store_data->product_order_by == 1)
                    {
                        $query->orderBy('products.id', 'desc');
                    }
                    elseif($store_data->product_order_by == 2)
                    {
                        $query->orderBy('products.price', 'DESC');
                    }
                    elseif($store_data->product_order_by == 3)
                    {
                        $query->orderBy('products.price', 'ASC');
                    }
                    elseif($store_data->product_order_by == 5)
                    {
                        $query->orderBy('products.name', 'ASC');
                    }
                    elseif($store_data->product_order_by == 6)
                    {
                        $query->orderBy('products.name', 'DESC');
                    }
                    elseif($store_data->product_order_by == 7)
                    {
                        $query->leftJoin('order_to_store', 'products.id', '=', 'order_to_store.product_id')
                                ->groupBy('products.id')
                                ->orderBy('ids', 'desc');
                        $order_ids = ",count(order_to_store.product_id) as ids";
                    }
                    else
                    {
                        $cat_id = $store_data->product_order_by - 100;
                        $query->leftJoin('category_relations', 'products.id', '=', 'category_relations.entity_id');
                        $query->where([
                            ['category_relations.relation_type', '=', "product"],
                            ['category_relations.deleted_at', null]
                        ]);
                        $query->orderByRaw('FIELD(category_relations.cat_id, "'.$cat_id.'") DESC');
                    }
                }
                else
                {
                    $query->orderBy('products.id', 'desc');
                }
            }
            $query->leftJoin('product_images as pimg','products.id', '=', 'pimg.product_id');
            $query = $query->select(DB::raw('DISTINCT(products.id), products.name,products.short_description,products.sku, products.price, products.sale_price, products.description,products.slug, products.item_fabric, products.custom_sizes, products.category_fields, ss.offline, pimg.image_path as image' . $order_ids . ''));
            
            $products = $query->distinct()->paginate(10);

            return response()->json(['data' => $products, 'status_code' => 200, 'status' => true], 200);
        } 
        catch (Exception $e) 
        {
            return Response::json(['status_code' => 500, 'error' => 'There is something wrong', 'status' => false], 500);
        }
    }

     /* Recent Product*/
    public function recent($language_id)
    {
        try 
        {
            $query = DB::table('products');
            if ($language_id && $language_id == 'ar') 
            {
                $query->where('lang', $language_id);
            }
            if($language_id && $language_id == 'en')
            {
                $query->where('lang', $language_id);
            }
            $query->leftJoin('product_images', 'products.id', '=', 'product_images.product_id');
            $query->where('product_images.is_featured', 1);
            $query->where('products.status', 1);
            $query->where('products.hide_product', 1);
            //$query->groupBy('products.store_id');
            $query->orderBy('products.id', 'DESC');
            $query->select('products.id','products.name', 'products.short_description','products.sku', 'products.price','products.sale_price','products.quantity', 'products.slug','product_images.image_path as image');
            $recent_products = $query->get();

            /* Fabric filter */
            /*$products_fabric = array();
            $item = array(); 
            if (count($recent_products) >= 1) 
            {
                foreach ($recent_products as $product) 
                {
                    $p_f = $product->item_fabric;
                    $products_fabric[$p_f] = $p_f;
                } 
            }
            if($products_fabric && count($products_fabric) > 0)
            {
                 foreach ($products_fabric as $fab_key => $fab)
                 {
                    $item = $fab;
                 }
            } 
*/
            /* End Fabric filter */
            if(count($recent_products) == 0)
            {
                return response()->json(['data' => 'Record Not Found', 'status_code' => 404, 'status' => flase],404); 
            }

            return response()->json(['data' => $recent_products, 'status_code' => 200, 'status' => true],200);   
        } 
        catch (Exception $e) 
        {
            return Response::json(['error' => 'There is something wrong', 'status_code' => 500, 'status' => false], 500);
        }
    }

    public function popular_products($language_id)
    {
        try
        {
            $query = DB::table('order_to_store as ots');
            if ($language_id && $language_id == 'ar') 
            {
                $query->where('p.lang', $language_id);
                $query->select(array('p.id','p.name','p.slug','p.short_description','p.sku','p.price','p.sale_price','p.is_featured','p.quantity', 'pimg.image_path as image','s.title','s.slug as store_slug', DB::raw('COUNT(ots.id) as total_sell'), DB::raw('IFNULL(s.ar_title, s.title) AS `title`')));
            }
            if($language_id && $language_id == 'en')
            {
                $query->where('p.lang', $language_id);
                $query->select(array('p.id','p.name','p.slug','p.short_description','p.sku','p.price','p.sale_price','p.is_featured','p.quantity', 'pimg.image_path as image','s.title','s.slug as store_slug', DB::raw('COUNT(ots.id) as total_sell')));
            }
            
            
            $query->leftJoin('products as p', 'ots.product_id', '=', 'p.id');
            $query->leftJoin('product_images as pimg', 'p.id', '=', 'pimg.product_id');
            $query->leftJoin('orders as o', 'ots.order_id', '=', 'o.id');
            $query->leftJoin('stores as s', 'p.store_id', '=', 's.id');
            $query->where('o.status', '!=', 'Rejected');
            $query->where('o.status', '!=', 'rejected');
            $query->where('o.status', '!=', 'unPaid');
            $query->where('o.status', '!=', 'in_progress');
            $query->where('o.status', '!=', 'on_hold');
            $query->where('o.status', '!=', 'cancelled');
            $query->where('o.status', '!=', 'declined');
            $query->groupBy('ots.product_id');
            $query->orderBy('total_sell', 'desc');
            $query->limit(12);
            $popular_products = $query->get();
            //
            
            /*$query = "SELECT count(os.id) as total_sell,os.product_id,p.`name`,p.slug,p.id,p.short_description,p.sku,p.price,p.sale_price,p.description,p.is_featured,p.quantity, pi.image_path as image
            FROM `order_to_store` os 
            LEFT JOIN products p ON p.id = os.product_id
            LEFT JOIN product_images  pi on p.id = pi.product_id 
            LEFT JOIn orders o ON o.id =os.order_id
            WHERE o.status != 'Rejected' AND o.status != 'rejected' AND o.status != 'unPaid' AND o.status != 'in_progress' AND o.status != 'on_hold' AND o.status != 'cancelled' AND pi.is_featured = 1
            AND o.status != 'declined'
            AND p.status = 1 
            AND p.deleted_at is NULL 
            AND hide_product = 1
            GROUP BY os.product_id ORDER BY total_sell DESC  LIMIT 12";
            //$query->where('products.lange', $language_id);
            $p_products = DB::select($query);
            //dd(count($p_products));
            $pro = array();
            if($language_id != 'en')
            {

                foreach ($p_products as $p_product)
                {
                    if($p_product->lang != 'en')
                    {
                        $pro[]  = $p_product;
                    }
                    else
                    {
                        $query = DB::table('products');
                        $query->select(DB::raw('products.*,products.`name`,products.slug,products.id'));
                        $query->leftJoin('stores as ss', 'products.store_id', '=', 'ss.id');
                        $query->leftJoin('product_images', 'products.id', '=', 'product_images.product_id');
                        $query->where('product_images.is_featured', 1);
                        $query->where('products.lang_content_type', $p_product->id);
                        $query->where('lang', 'ar');
                        $p = $query->first();
                        if($p && count($p) > 0)
                        {
                            $pro[] = $p;
                        }
                    }
                }
                $popular_products = (Object) $pro;
            }
            else
            {
                $popular_products = $p_products;
            }*/
            return response()->json(['data' => $popular_products, 'status_code' => 200, 'status' => true],200);   
        } 
        catch (Exception $e) 
        {
            return Response::json(['error' => 'There is something wrong', 'status_code' => 500, 'status' => false], 500);
        }
    }

    public function get_product_image($product_id)
    {
        $path   =   url('front/images/placeholder.png');
        try 
        {
            $product_image = DB::table("product_images")
                            ->where('product_id', $product_id)
                            ->where('is_featured', 1)
                            ->first();
            if(count($product_image) == 0)
            {
                return response()->json(['data' => 'Record Not Found', 'status_code' => 404, 'status' => flase],404); 
            }
            if($product_image) 
            {
                if($product_image->thumbnail_path) 
                {
                    $path   =   $product_image->thumbnail_path;
                } 
                else 
                {
                    $path   =   $product_image->image_path;
                }
            }
           return response()->json(['data' => $path, 'status_code' => 200, 'status' => true],200);   
        } 
        catch (Exception $e) 
        {
            return Response::json(['error' => 'There is something wrong', 'status_code' => 500, 'status' => false], 500);
        }
    }

    
}
