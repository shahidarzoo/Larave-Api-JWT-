<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Products;
use App\Wishlist;
use DB;
use App\ProductVariations;
use App\WaredrobeProduct;
use Response;

class WardrobeController extends Controller
{
    public function wardrobe_list()
    {
    	try 
    	{
    		$query = DB::table('waredrobe_product');
    		$query->leftJoin('users', 'users.id', '=', 'waredrobe_product.user_id');
	        $query->leftJoin('stores', 'users.id', '=', 'stores.user_id');
	        $query->leftJoin('products as p', 'p.store_id', '=', 'waredrobe_product.product_id');
	        $query->select(DB::raw('DISTINCT(title),waredrobe_product.id, CONCAT(users.first_name," ",users.last_name) as wardrobe_name, stores.slug,logo_path,wardrobe_banner'));
	        $query->orderBy('title', 'desc');
	        $wardrobe = $query->get();
	        if(count($wardrobe) == 0)
	        {
	        	return response()->json(['error' => 'Record Not found', 'status_code' => 404, 'status' => false], 404);
	        }
    	   return response()->json(['data' => $wardrobe, 'status_code' => 200, 'status' => true], 200);  
        } 
        catch (Exception $e) 
        {
            return Response::json(['status_code' => 500, 'error' => 'There is something wrong', 'status' => false], 500);
        }
    }

   	public function profile($alias)
   	{
   		try 
   		{
   			$store_data = DB::table("stores")
					->where('stores.slug', $alias)
					->where('stores.status', '=', 1)
					->whereNull('users.deleted_at')
					->leftJoin('users', 'users.id', '=', 'stores.user_id')
					->select('users.first_name','users.last_name','users.wardrobe_banner','stores.title','stores.slug','stores.description','stores.url','stores.logo_path','stores.facebook_handle','stores.twitter_handle','stores.linkedin_handle','stores.instagram_handle')
					->first();	
   			if(count($store_data) == 0)
	        {
	        	return response()->json(['error' => 'Record Not found', 'status_code' => 404, 'status' => false], 404);
	        }
    	   return response()->json(['data' => $store_data, 'status_code' => 200, 'status' => true], 200);  
        } 
        catch (Exception $e) 
        {
            return Response::json(['status_code' => 500, 'error' => 'There is something wrong', 'status' => false], 500);
        }
   	}
}
