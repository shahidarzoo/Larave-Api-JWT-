<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Products;
use App\Wishlist;
use Auth;
use DB;
use Response;
use App\ProductVariations;
use Validator;
use App\Subscribers;

class WishListController extends Controller
{
    public function index(Request $request)
    {
    	try 
    	{
    		$product_id = $request->product_id;
            $product_data = Products::where('id', $product_id)->first();
            if ($request->user_id) 
            {
                $product_cart_ar = array();

                $size_id = $request->size_id;
                $color_id = $request->color_id;
                $qty = $request->quantity;
                $variation_id = $request->variation_id;
                $custom_spec = $request->custom_spec;
                $total_price = $product_data->price;

    			$product_cart_ar = [
    			'id' => $product_data->id, 
                'name' => $product_data->name, 
                'qty' => $qty, 
                'price' => $total_price, 
                'taxRate' => 3, 
                'options' => [
                	'size' => $size_id, 
                	'color_id' => $color_id, 
                	'store_id' => $product_data->store_id, 
                	'slug' => $product_data->slug, 
                	'variation_id' => $variation_id, 
                	'custom_spec' => $custom_spec
                ]];

	            $wishlist = Wishlist::where(['product_id' => $product_id, 'user_id' => $request->user_id])->get();
	            if (count($wishlist) >= 1) 
	            {
	                return response()->json(['data' => 'Product already added in your wish list', 'status_code'=> 200, 'status' => true],200);
	            }
	            $Wishlist = new Wishlist();
	            $Wishlist->product_id = $product_id;
	            $Wishlist->wishlist_detail = json_encode($product_cart_ar);
	            $Wishlist->size_id = $size_id;
	            $Wishlist->color_id = $color_id;
	            $Wishlist->user_id = $request->user_id;
	            $Wishlist->save();
	            return response()->json(['data' => 'Product aded in your wish list', 'status_code'=> 200, 'status' => true],200);
	        }
    	} 
    	catch (Exception $e) 
    	{
    		return Response::json(['error' => 'There is something wrong','status_code' => 500, 'status' => false],500);
    	}
    }

	public function subscriber(Request $request)
	{
		try 
		{
			$validator = Validator::make($request->all(), [
            	'email' => 'required|email'
            ]);
            if($validator->fails())
            {
                return response()->json(['error' => $validator->errors(), 'status_code' => 500, 'status' => false], 500);
            }
            $subscriber = new Subscribers();
            $subscriber->email = $request->email;
            $res = $subscriber->save();
            $data = array('email' => $request->email, 'status' => 'subscribed', 'message' => 'Thanks for subscribed');
            mailchimp($data);
            return response()->json(['data' => 'Subscribed Successfully', 'status_code'=> 200, 'status' => true],200);	
		} 
		catch (Exception $e) 
    	{
    		return Response::json(['error' => 'There is something wrong','status_code' => 500, 'status' => false],500);
    	}
	}

    public function wish_list($user_id)
    {
        try 
        {
            $query = DB::table('whish_list');
            $query->join('products', 'whish_list.product_id', '=', 'products.id');
            $query->join('colours', 'whish_list.color_id', '=', 'colours.id');
            $query->join('sizes', 'whish_list.size_id', '=', 'sizes.id');
            $query->where('whish_list.user_id', $user_id);
            $query->whereNull('colours.deleted_at');
            $query->whereNull('sizes.deleted_at');
            $query->select('whish_list.id','products.name', 'products.price', 'sizes.name as size_name','colours.name as color_name');
            $whish_list = $query->get();
            if(count($whish_list) == 0)
            {
                return response()->json(['error' => 'Record Not found', 'status_code'=> 200, 'status' => true],200); 
            }

            return response()->json(['data' => $whish_list, 'status_code'=> 200, 'status' => true],200); 
        } 
        catch (Exception $e) 
        {
            return Response::json(['error' => 'There is something wrong','status_code' => 500, 'status' => false],500);
        }
    }

}
