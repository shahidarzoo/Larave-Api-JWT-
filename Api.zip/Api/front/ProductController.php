<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Products;
use DB;
use Response;
use App\Models\Category;
use App\CustomMeasurements;
use Illuminate\Session\Store;
use App\Models\CategoryRelation;
use App\Stores;
use App\ProductVariations;
use App\Tags;

class ProductController extends Controller
{
	// Product Details
    public function index(Request $request)
    {
    	try 
    	{
    		/*$products = Products::select(['products.id', 'products.name', 'products.short_description', 'products.price', 'products.sale_price'])
    				->where('products.deleted_at', '=', null)
    				->groupBy('products.store_id')
    				->paginate(10);*/
            $page_id = '';
        $category_obj = '';


        $order_ids = "";
        $cache_enabled = config('cache.enabled_listing_item');
        $cache_duration = config('cache.duration');
        $cache_prefix = config('cache.cache_prefix');
        $cache_enabled = false;
        $key = 'category_products_load';
        if ($request->segment(1) != NULL) {
            $key .= '_' . $request->segment(1);
        }
        if ($request->segment(2) != NULL) {
            $key .= '_' . $request->segment(2);
        }

        if ($_GET['page'] != NULL) {
            $key .= '_' . $_GET['page'];
        }

        $query = DB::table('products');
        $query->where(["products.status" => 1, "products.hide_product" => 1, 'products.deleted_at' => null]);
        $query->leftJoin('stores as ss', 'products.store_id', '=', 'ss.id');

        //apply store filter
        $store_data = "";
        $segment1 = $request->segment(1);
        if ($segment1 == "search") {
            $page_id = 'search';

            $key .= '_' . $request->input('s');
            $query_string = $request->input('s');

            $category_obj = DB::table('categories')->where("name", 'like', "%{$query_string}%")->where(["status" => 1, "parent_id" => 0, 'deleted_at' => null])->take(1)->first();
            $search_cat_id = $category_obj->id;


            $color_obj = DB::table('colours')->where("name", 'like', "%{$query_string}%")->take(1)->first();
            $color_id = $color_obj->id;
            $color_condition = '';
            if ($color_id) {
                $query->Join('product_variations as pv', 'products.id', '=', 'pv.product_id');
                $color_condition = true;
            }

            $size_obj = DB::table('sizes')->where("name", 'like', "%{$query_string}%")->take(1)->first();
            $size_id = $size_obj->id;
            $size_condition = '';
            if ($size_id) {
                $query->Join('product_variations', 'products.id', '=', 'product_variations.product_id');
                $size_condition = true;
            }

            $store_obj = DB::table('stores')->where("title", 'like', "%{$query_string}%")->take(1)->first();
            $store_id = $store_obj->id;
            $store_condition = '';
            if ($store_id) {
                $store_condition = true;
            }


            if ($search_cat_id) {
                $category_id = $search_cat_id;
                $query->join('category_relations', 'products.id', '=', 'category_relations.entity_id');
                $query->leftJoin('product_to_tags as p_to_c', 'p_to_c.fk_product_id', '=', 'products.id');
                $query->leftJoin('category_to_tags as c_to_t', 'c_to_t.fk_tags_id', '=', 'p_to_c.fk_tags_id');
                $query->where(function ($query) use ($category_id, $query_string) {
                    $query->orWhere([
                        ['category_relations.cat_id', '=', $category_id],
                        ['category_relations.relation_type', '=', "product"],
                        ['category_relations.deleted_at', null]
                    ])->orWhere('c_to_t.fk_category_id', '=', $category_id)->orWhere('products.name', 'like', "%{$query_string}%")->orWhere('products.short_description', 'like', "%{$query_string}%");
                });
            } else {
                $query->where(function ($query) use ($color_condition, $size_condition, $store_condition, $color_id, $size_id, $store_id, $query_string) {
                    $query->where('products.name', 'like', "%{$query_string}%")->orWhere('products.short_description', 'like', "%{$query_string}%");
                    if ($color_condition) {
                        $query->orWhere('pv.color_id', $color_id);
                    }
                    if ($size_condition) {
                        $query->orWhere('product_variations.size_id', $size_id);
                    }
                    if ($store_condition) {
                        $query->orWhere('products.store_id', $store_id);
                    }
                });
            }
        }
        if ($request->segment(2) != NULL && $request->segment(2) == "recent") {
            $page_id = 'recent_product';
            $query->orderBy('products.created_at', 'DESC');
        }
        if ($request->segment(2) != NULL && $request->segment(2) == "trending") {
            $page_id = 'trending_product';
            $query->leftJoin('order_to_store', 'products.id', '=', 'order_to_store.product_id')
                    ->groupBy('products.id')
                    ->orderBy('ids', 'desc');
            $order_ids = ",count(order_to_store.product_id) as ids";
        }

        //apply color filter
        if (is_array($request->input('colors')) && count($request->input('colors')) >= 1) {
            $key .= '_' . json_encode($request->input('colors'));
            $query->Join('product_variations as pv', 'products.id', '=', 'pv.product_id');
            $query->whereIn('pv.color_id', $request->input('colors'));
        }
        //apply size filter
        if (is_array($request->input('sizes')) && count($request->input('sizes')) >= 1) {
            $key .= '_' . json_encode($request->input('sizes'));
            $query->Join('product_variations', 'products.id', '=', 'product_variations.product_id');
            $query->whereIn('product_variations.size_id', $request->input('sizes'));
        }
        if ($request->input('fabric')) {
            $fabric = $request->input('fabric');
            $query->where('products.item_fabric', 'like', "%{$fabric}%");
        }

        //apply category filter
        $category_id = "";
        $filter_type_text = "";
        $filters = array();
        if ($segment1 == "category") {
            $page_id = 'category';
            $alias = $request->segment(2);
            
                $category_obj = Category::where("alias", $alias)->take(1)->first();
                $filter_type_text = $category_obj->filter_type;
                $category_id = $category_obj->id;
                //dd( $category_obj->filter_type);
            if (empty($category_id) && !is_numeric($category_id)) {
                abort(404);
            }
            $query->join('category_relations', 'products.id', '=', 'category_relations.entity_id');
            $query->leftJoin('product_to_tags as p_to_c', 'p_to_c.fk_product_id', '=', 'products.id');
            $query->leftJoin('category_to_tags as c_to_t', 'c_to_t.fk_tags_id', '=', 'p_to_c.fk_tags_id');
            $query->where(function ($query) use ($category_id) {
                $query->where([
                    ['category_relations.cat_id', '=', $category_id],
                    ['category_relations.relation_type', '=', "product"],
                    ['category_relations.deleted_at', null]
                ])->orWhere('c_to_t.fk_category_id', '=', $category_id);
            });

            $tags_filters = Tags::select("tags.id", "tags.title")->join('category_to_tags as tag', 'tags.id', '=', 'tag.fk_tags_id')->where("tag.fk_category_id", $category_id)->orderBy('tags.title', 'ASC')->get();
            if (!empty($request->input('tags'))) {
                $key .= '_tag' . $request->input('tags');
                $query->whereIn('c_to_t.fk_tags_id', $request->input('tags'));
            }

            //session(['key_last_category_visit' => $alias]);
            $filters = Category::where("id", $category_id)->take(1)->value('filters');
            $filters = json_decode($filters);
        }
        //apply store filter
        $store_data = "";
        if ($segment1 == "store") {
            $page_id = 'store';
            $alias = $request->segment(2);

            if ($cache_enabled) {
                $key3 = $cache_prefix . '_get_store_info_by_alias_' . $alias;
                $store_data = Cache::remember($key3, $cache_duration, function () use ($alias) {
                            return DB::table("stores")->where([
                                        ['slug', '=', $alias],
                                        ['status', '=', 1],
                                        ['deleted_at', null]
                                    ])->take(1)->first();
                        });
            } else {
                $store_data = DB::table("stores")->where([
                            ['slug', '=', $alias],
                            ['status', '=', 1],
                            ['deleted_at', null]
                        ])->take(1)->first();
            }
            $store_id = $store_data->id;
            if (empty($store_id) && !is_numeric($store_id)) {
                abort(404);
            }
            $query->where("products.store_id", $store_id);
        }
        //apply ajax brand/store filter
        if (is_array($request->input('brands')) && count($request->input('brands')) >= 1) {
            $request->input('brands');
            $alias = $request->segment(2);
            $query->join('stores', 'products.store_id', '=', 'stores.id')
                    ->whereIn('stores.id', $request->input('brands'));

            $category_ids = CategoryRelation::whereIn('entity_id', $request->input('brands'))
                            ->where('relation_type', 'store')->pluck('cat_id');
                           
            $cat_ids = [];
            foreach ($category_ids as $key => $cat_val) {
                array_push($cat_ids, $cat_val);
            }
            $query->join('category_relations as cr', 'products.id', '=', 'cr.entity_id')
                    ->where(function ($query) use ($cat_ids) {
                        $query->where(function ($query) use ($cat_ids) {
                            $query->whereIn('cr.cat_id', $cat_ids)
                            ->where('cr.relation_type', "product")
                            ->where('cr.deleted_at', null);
                        })->orWhereIn('c_to_t.fk_category_id', $cat_ids);
                    });
        }
        
           //apply ajax brand/store filter
        if (is_array($request->input('brands_new')) && count($request->input('brands_new')) >= 1) {

            $request->input('brands_new');
            $alias = $request->segment(2);
            $query->join('stores', 'products.store_id', '=', 'stores.id')
                    ->whereIn('stores.id', $request->input('brands_new'));

            $category_ids = CategoryRelation::whereIn('entity_id', $request->input('brands_new'))
                            ->where('relation_type', 'store')->pluck('cat_id');
                           
            $cat_ids = [];
            foreach ($category_ids as $key => $cat_val) {
                array_push($cat_ids, $cat_val);
            }
            $query->join('category_relations as cr', 'products.id', '=', 'cr.entity_id')
                    ->where(function ($query) use ($cat_ids) {
                        $query->where(function ($query) use ($cat_ids) {
                            $query->whereIn('cr.cat_id', $cat_ids)
                            ->where('cr.relation_type', "product")
                            ->where('cr.deleted_at', null);
                        });
                    });
        } 
           //Category Filter
        if (is_array($request->input('category_id2')) && count($request->input('category_id2')) >= 1) {

            $category_id=$request->input('category_id2');           
            $alias = $request->segment(2);

            $query->join('category_relations', 'products.id', '=', 'category_relations.entity_id');
            $query->leftJoin('product_to_tags as p_to_c', 'p_to_c.fk_product_id', '=', 'products.id');
            $query->leftJoin('category_to_tags as c_to_t', 'c_to_t.fk_tags_id', '=', 'p_to_c.fk_tags_id');
            $query->whereIn('category_relations.cat_id', $category_id);
            $query->where('category_relations.relation_type', 'product');
            
            
        }

        //Price Range Filter
        if (!empty($request->input('price_range'))) {
            $key .= '_' . $request->input('price_range');
            $price_range = explode(";", $request->input('price_range'));
            $query->whereBetween('products.price', [$price_range[0], $price_range[1]]);
        }


        if ($request->input('sort')) {
            $sort = $request->input('sort');
            $key .= '_' . $sort;
            if ($sort == 1) {
                $query->orderBy('products.created_at', 'desc');
            } elseif ($sort == 2) {
                $query->orderBy('products.price', 'asc');
            } elseif ($sort == 3) {
                $query->orderBy('products.price', 'desc');
            } elseif ($sort == 4) {
                $query->leftJoin('order_to_store', 'products.id', '=', 'order_to_store.product_id')
                        ->groupBy('products.id')
                        ->orderBy('ids', 'desc');
                $order_ids = ",count(order_to_store.product_id) as ids";
            }
        } else if ($segment1 == "category") {
            $key .= '_orderbyidss';
            $query->orderBy('products.id', 'desc');
        } else {
            $key .= '_productid';
            if ($segment1 == "store") {
                if($store_data->product_order_by == 1){
                    $query->orderBy('products.id', 'desc');
                }elseif($store_data->product_order_by == 2){
                    $query->orderBy('products.price', 'DESC');
                }elseif($store_data->product_order_by == 3){
                    $query->orderBy('products.price', 'ASC');
                }elseif($store_data->product_order_by == 5){
                    $query->orderBy('products.name', 'ASC');
                }elseif($store_data->product_order_by == 6){
                    $query->orderBy('products.name', 'DESC');
                }elseif($store_data->product_order_by == 7){
                    $query->leftJoin('order_to_store', 'products.id', '=', 'order_to_store.product_id')
                    ->groupBy('products.id')
                    ->orderBy('ids', 'desc');
                    $order_ids = ",count(order_to_store.product_id) as ids";
                }else{
                    $cat_id = $store_data->product_order_by - 100;
                    $query->leftJoin('category_relations', 'products.id', '=', 'category_relations.entity_id');
                    $query->where([
                        ['category_relations.relation_type', '=', "product"],
                        ['category_relations.deleted_at', null]
                    ]);
                    $query->orderByRaw('FIELD(category_relations.cat_id, "'.$cat_id.'") DESC');
                }
            }else{
                $query->orderBy('products.id', 'desc');
            }
            
            
            
            
        }
        $query = $query->select(DB::raw('DISTINCT(products.id), "products.id", "products.name", "products.short_description", "products.price", "products.sale_price", ss.offline' . $order_ids . ''));
        if ($cache_enabled) {
            $key = $cache_prefix . '_' . $key;
            $products = Cache::remember($key, $cache_duration, function () use ($query) {
                        return $query->distinct()->paginate(12, ['products.id']);
                    });
        } else {
            $products = $query->distinct()->paginate(12, ['products.id']);
        }
		if(count($products) == 0)
		{
			return response()->json(['status_code' => 404, 'error' => 'Records not found', 'status' => false], 404);
		}
		return response()->json(['data'=> $products, 'status_code' => 200, 'status' => true], 200);
    	} 
    	catch (Exception $e) 
    	{
    		return Response::json(['status_code' => 500, 'error' => 'There is an error', 'status' => false], 500);	
    	}
    }
 	// Product Base on Category
    public function category_products($alias)
    {
    	try 
    	{

            $product_to_cateogry = Category::join('category_relations', 'categories.id', '=', 'category_relations.cat_id')
    					->leftJoin('products', 'category_relations.entity_id', '=', 'products.id')
    					->leftJoin('stores', 'products.store_id', '=', 'stores.id')
    					->leftJoin('product_to_tags as ptags', 'products.id','=', 'ptags.fk_product_id')
    					->leftJoin('category_to_tags as ctags', 'ctags.fk_tags_id', '=', 'categories.id')
    					->groupBy('products.store_id')
    					->where('category_relations.deleted_at', null)
    					->where('categories.alias',$alias)
    					->where('categories.deleted_at',null)
                        ->select('products.id', 'products.name','products.price', 'products.sale_price','products.description','products.no_of_days','products.item_fabric','categories.image_url','categories.order_number','products.slug','products.custom_sizes','products.category_fields')
    					->paginate(10);
    		if(count($product_to_cateogry) == 0)
    		{
    			return response()->json(['status_code' => 404, 'error' => 'Records not fount', 'status' => false], 404);
    		}
    		return response()->json(['data' => $product_to_cateogry, 'status_code' => 200, 'status' => true], 200);
    	} 
    	catch (Exception $e) 
    	{
    		return Response::json(['status_code' => 500, 'error' => 'There is something wrong', 'status' => false], 500);
    	}
    }
    // single product with slug
    public function show($slug)
    {
    	try 
    	{
    		$product = Products::select('products.*')
    				->where('products.deleted_at', '=', Null)
    				->where('products.slug', $slug)
    				->groupBy('products.store_id')
    				->first();
    		if(count($product) == 0)
    		{
    			return response()->json(['status_code' => 404, 'error' => 'Record not found', 'status' => false], 404);
    		}
    		return response()->json(['data' => $product, 'status_code' => 200, 'status' => true], 200);
    	} 
    	catch (Exception $e) 
    	{
    		return Response::json(['status_code' => 500, 'error' => 'There is some thing wrong', 'status' => false], 500);
    	}
    }

    public function search(Request $request)
    {
        try 
        {
            /*$name = $request->name;
            $product_to_cateogry = Category::join('category_relations', 'categories.id', '=', 'category_relations.cat_id')
                        ->leftJoin('products', 'category_relations.entity_id', '=', 'products.id')
                        ->leftJoin('stores', 'products.store_id', '=', 'stores.id')
                        ->leftJoin('product_to_tags as ptags', 'products.id','=', 'ptags.fk_product_id')
                        ->leftJoin('category_to_tags as ctags', 'ctags.fk_tags_id', '=', 'categories.id')
                        ->where('category_relations.deleted_at', null)
                        ->where('products.name', 'like', '%'.$name.'%')
                        ->where('categories.deleted_at',null)
                        ->select('products.id', 'products.name','products.price', 'products.sale_price','products.description','products.no_of_days','products.item_fabric','categories.image_url','categories.order_number','products.slug','products.custom_sizes','products.category_fields')
                        ->paginate(10);*/



            /*if(count($product_to_cateogry) == 0)
            {
                return response()->json(['status_code' => 404, 'error' => 'Records not fount', 'status' => false], 404);
            }*/
            $page_id = '';
            $category_obj = '';

            $order_ids = "";
            $cache_enabled = config('cache.enabled_listing_item');
            $cache_duration = config('cache.duration');
            $cache_prefix = config('cache.cache_prefix');
            $cache_enabled = false;

            $key = 'category_products_load';
            if ($request->segment(2) != NULL) 
            {
                $key .= '_' . $request->segment(1);
            }
            if ($request->segment(3) != NULL) 
            {
                $key .= '_' . $request->segment(2);
            }

            if ($_GET['page'] != NULL) 
            {
                $key .= '_' . $_GET['page'];
            }
            $query = DB::table('products');
            $query->where(["products.status" => 1, "products.hide_product" => 1, 'products.deleted_at' => null]);
            $query->leftJoin('stores as ss', 'products.store_id', '=', 'ss.id');
            //dd( $query->get());
            //apply store filter
            $store_data = "";
            $segment1 = $request->segment(1);
            
            $page_id = 'search';

            $key .= '_' . $request->name;
            $query_string = $request->name;

            $category_obj = DB::table('categories')->where("name", 'like', "%{$query_string}%")->where(["status" => 1, "parent_id" => 0, 'deleted_at' => null])->take(1)->first();
            $search_cat_id = $category_obj->id;


            $color_obj = DB::table('colours')->where("name", 'like', "%{$query_string}%")->take(1)->first();
            $color_id = $color_obj->id;

            $color_condition = '';
            if ($color_id) 
            {
                $query->Join('product_variations as pv', 'products.id', '=', 'pv.product_id');
                $color_condition = true;
            }

            $size_obj = DB::table('sizes')->where("name", 'like', "%{$query_string}%")->take(1)->first();
            $size_id = $size_obj->id;
            $size_condition = '';
            if ($size_id) 
            {
                $query->Join('product_variations', 'products.id', '=', 'product_variations.product_id');
                $size_condition = true;
            }

            $store_obj = DB::table('stores')->where("title", 'like', "%{$query_string}%")->take(1)->first();
            $store_id = $store_obj->id;

            $store_condition = '';
            if ($store_id) 
            {
                $store_condition = true;
            }


            if ($search_cat_id) 
            {
                $category_id = $search_cat_id;
                $query->join('category_relations', 'products.id', '=', 'category_relations.entity_id');
                $query->leftJoin('product_to_tags as p_to_c', 'p_to_c.fk_product_id', '=', 'products.id');
                $query->leftJoin('category_to_tags as c_to_t', 'c_to_t.fk_tags_id', '=', 'p_to_c.fk_tags_id');
                $query->where(function ($query) use ($category_id, $query_string) 
                {
                    $query->orWhere([
                        ['category_relations.cat_id', '=', $category_id],
                        ['category_relations.relation_type', '=', "product"],
                        ['category_relations.deleted_at', null]
                    ])->orWhere('c_to_t.fk_category_id', '=', $category_id)
                    ->orWhere('products.name', 'like', "%{$query_string}%")
                    ->orWhere('products.short_description', 'like', "%{$query_string}%");
                });
                
            } 
            else 
            {
                $query->where(function ($query) use ($color_condition, $size_condition, $store_condition, $color_id, $size_id, $store_id, $query_string) 
                {
                    $query->where('products.name', 'like', "%{$query_string}%")
                            ->orWhere('products.short_description', 'like', "%{$query_string}%");
                    if ($color_condition) 
                    {
                        $query->orWhere('pv.color_id', $color_id);
                    }
                    if ($size_condition) 
                    {
                        $query->orWhere('product_variations.size_id', $size_id);
                    }
                    if ($store_condition) 
                    {
                        $query->orWhere('products.store_id', $store_id);
                    }
                });
            }
            if ($request->segment(3) != NULL && $request->segment(2) == "recent") 
            {
                $page_id = 'recent_product';
                $query->orderBy('products.created_at', 'DESC');
            }
            if ($request->segment(3) != NULL && $request->segment(2) == "trending") 
            {
                $page_id = 'trending_product';
                $query->leftJoin('order_to_store', 'products.id', '=', 'order_to_store.product_id')
                    ->groupBy('products.id')
                    ->orderBy('ids', 'desc');
                $order_ids = ",count(order_to_store.product_id) as ids";
            }

            //apply color filter
            if (is_array($request->colors) && count($request->colors) >= 1) 
            {
                $key .= '_' . json_encode($request->input('colors'));
                $query->Join('product_variations as pv', 'products.id', '=', 'pv.product_id');
                $query->whereIn('pv.color_id', $request->input('colors'));
            }
            //apply size filter
            if (is_array($request->sizes) && count($request->sizes) >= 1) 
            {
                $key .= '_' . json_encode($request->sizes);
                $query->Join('product_variations', 'products.id', '=', 'product_variations.product_id');
                $query->whereIn('product_variations.size_id', $request->sizes);
            }
            if($request->fabric) 
            {
                $fabric = $request->fabric;
                $query->where('products.item_fabric', 'like', "%{$fabric}%");
            }

            //apply category filter
            $category_id = "";
            $filter_type_text = "";
            $filters = array();
            if ($segment1 == "category") 
            {
                $page_id = 'category';
                $alias = $request->segment(2);
                
                    $category_obj = Category::where("alias", $alias)->take(1)->first();
                    $filter_type_text = $category_obj->filter_type;
                    $category_id = $category_obj->id;
                    //dd( $category_obj->filter_type);
                if (empty($category_id) && !is_numeric($category_id)) 
                {
                    abort(404);
                }
                $query->join('category_relations', 'products.id', '=', 'category_relations.entity_id');
                $query->leftJoin('product_to_tags as p_to_c', 'p_to_c.fk_product_id', '=', 'products.id');
                $query->leftJoin('category_to_tags as c_to_t', 'c_to_t.fk_tags_id', '=', 'p_to_c.fk_tags_id');
                $query->where(function ($query) use ($category_id) 
                {
                    $query->where([
                        ['category_relations.cat_id', '=', $category_id],
                        ['category_relations.relation_type', '=', "product"],
                        ['category_relations.deleted_at', null]
                    ])->orWhere('c_to_t.fk_category_id', '=', $category_id);
                });

                $tags_filters = Tags::select("tags.id", "tags.title")
                                ->join('category_to_tags as tag', 'tags.id', '=', 'tag.fk_tags_id')
                                ->where("tag.fk_category_id", $category_id)
                                ->orderBy('tags.title', 'ASC')
                                ->get();
                if (!empty($request->tags)) 
                {
                    $key .= '_tag' . $request->tags;
                    $query->whereIn('c_to_t.fk_tags_id', $request->tags);
                }

                //session(['key_last_category_visit' => $alias]);
                $filters = Category::where("id", $category_id)
                            ->take(1)
                            ->value('filters');
                $filters = json_decode($filters);
            }
            //apply store filter
            $store_data = "";
            if ($segment1 == "store") 
            {
                $page_id = 'store';
                $alias = $request->segment(2);

                if ($cache_enabled) 
                {
                    $key3 = $cache_prefix . '_get_store_info_by_alias_' . $alias;
                    $store_data = Cache::remember($key3, $cache_duration, function () use ($alias) 
                    {
                        return DB::table("stores")->where([
                            ['slug', '=', $alias],
                            ['status', '=', 1],
                            ['deleted_at', null]
                        ])->take(1)
                        ->first();
                        });
                } 
                else 
                {
                    $store_data = DB::table("stores")->where([
                            ['slug', '=', $alias],
                            ['status', '=', 1],
                            ['deleted_at', null]
                        ])->take(1)
                        ->first();
                }
                $store_id = $store_data->id;
                if (empty($store_id) && !is_numeric($store_id)) 
                {
                    abort(404);
                }
                $query->where("products.store_id", $store_id);
            }
            //apply ajax brand/store filter
            if (is_array($request->brands) && count($request->brands) >= 1) 
            {
                $request->brands;
                $alias = $request->segment(2);
                $query->join('stores', 'products.store_id', '=', 'stores.id')
                        ->whereIn('stores.id', $request->brands);

                $category_ids = CategoryRelation::whereIn('entity_id', $request->brands)
                                ->where('relation_type', 'store')
                                ->pluck('cat_id');
                               
                $cat_ids = [];
                foreach ($category_ids as $key => $cat_val) 
                {
                    array_push($cat_ids, $cat_val);
                }
                $query->join('category_relations as cr', 'products.id', '=', 'cr.entity_id')
                        ->where(function ($query) use ($cat_ids) {
                            $query->where(function ($query) use ($cat_ids) {
                                $query->whereIn('cr.cat_id', $cat_ids)
                                ->where('cr.relation_type', "product")
                                ->where('cr.deleted_at', null);
                            })->orWhereIn('c_to_t.fk_category_id', $cat_ids);
                        });
            }
            
               /* apply ajax brand/store filter */
            if (is_array($request->brands_new) && count($request->brands_new) >= 1) 
            {

                $request->input('brands_new');
                $alias = $request->segment(2);
                $query->join('stores', 'products.store_id', '=', 'stores.id')
                        ->whereIn('stores.id', $request->input('brands_new'));

                $category_ids = CategoryRelation::whereIn('entity_id', $request->brands_new)
                                ->where('relation_type', 'store')
                                ->pluck('cat_id');
                               
                $cat_ids = [];
                foreach ($category_ids as $key => $cat_val) 
                {
                    array_push($cat_ids, $cat_val);
                }
                $query->join('category_relations as cr', 'products.id', '=', 'cr.entity_id')
                        ->where(function ($query) use ($cat_ids) 
                        {
                            $query->where(function ($query) use ($cat_ids) 
                            {
                                $query->whereIn('cr.cat_id', $cat_ids)
                                ->where('cr.relation_type', "product")
                                ->where('cr.deleted_at', null);
                            });
                        });
            } 
               //Category Filter
            if (is_array($request->category_id2) && count($request->category_id2) >= 1) 
            {

                $category_id = $request->category_id2;           
                $alias = $request->segment(2);

                $query->join('category_relations', 'products.id', '=', 'category_relations.entity_id');
                $query->leftJoin('product_to_tags as p_to_c', 'p_to_c.fk_product_id', '=', 'products.id');
                $query->leftJoin('category_to_tags as c_to_t', 'c_to_t.fk_tags_id', '=', 'p_to_c.fk_tags_id');
                $query->whereIn('category_relations.cat_id', $category_id);
                $query->where('category_relations.relation_type', 'product');
                
                
            }

            //Price Range Filter
            if (!empty($request->price_range)) 
            {
                $key .= '_' . $request->price_range;
                $price_range = explode(";", $request->price_range);
                $query->whereBetween('products.price', [$price_range[0], $price_range[1]]);
            }


            if ($request->sort) 
            {
                $sort = $request->sort;
                $key .= '_' . $sort;
                if ($sort == 1) 
                {
                    $query->orderBy('products.created_at', 'desc');
                } 
                elseif ($sort == 2) 
                {
                    $query->orderBy('products.price', 'asc');
                } 
                elseif ($sort == 3) 
                {
                    $query->orderBy('products.price', 'desc');
                } 
                elseif ($sort == 4) 
                {
                    $query->leftJoin('order_to_store', 'products.id', '=', 'order_to_store.product_id')
                            ->groupBy('products.id')
                            ->orderBy('ids', 'desc');
                    $order_ids = ",count(order_to_store.product_id) as ids";
                }
            } 
            else if ($segment1 == "category") 
            {
                $key .= '_orderbyidss';
                $query->orderBy('products.id', 'desc');
            } 
            else 
            {
                $key .= '_productid';
                if ($segment1 == "store") 
                {
                    if($store_data->product_order_by == 1)
                    {
                        $query->orderBy('products.id', 'desc');
                    }
                    elseif($store_data->product_order_by == 2)
                    {
                        $query->orderBy('products.price', 'DESC');
                    }
                    elseif($store_data->product_order_by == 3)
                    {
                        $query->orderBy('products.price', 'ASC');
                    }
                    elseif($store_data->product_order_by == 5)
                    {
                        $query->orderBy('products.name', 'ASC');
                    }
                    elseif($store_data->product_order_by == 6)
                    {
                        $query->orderBy('products.name', 'DESC');
                    }
                    elseif($store_data->product_order_by == 7)
                    {
                        $query->leftJoin('order_to_store', 'products.id', '=', 'order_to_store.product_id')
                                ->groupBy('products.id')
                                ->orderBy('ids', 'desc');
                        $order_ids = ",count(order_to_store.product_id) as ids";
                    }
                    else
                    {
                        $cat_id = $store_data->product_order_by - 100;
                        $query->leftJoin('category_relations', 'products.id', '=', 'category_relations.entity_id');
                        $query->where([
                            ['category_relations.relation_type', '=', "product"],
                            ['category_relations.deleted_at', null]
                        ]);
                        $query->orderByRaw('FIELD(category_relations.cat_id, "'.$cat_id.'") DESC');
                    }
                }
                else
                {
                    $query->orderBy('products.id', 'desc');
                }
            }
            $query = $query->select(DB::raw('DISTINCT(products.id), products.name,products.short_description,products.sku, products.price, products.sale_price, products.description,products.slug, products.item_fabric, products.custom_sizes, products.category_fields, ss.offline' . $order_ids . ''));
            if ($query) 
            {
                $key = $cache_prefix . '_' . $key;
                $products = \Cache::remember($key, $cache_duration, function () use ($query) 
                {
                    return $query->distinct()->paginate(12, ['products.id']);
                });
            } 
            else 
            {
                $products = $query->distinct()->paginate(12, ['products.id']);
            }

            return response()->json(['data' => $products, 'status_code' => 200, 'status' => true], 200);
        } 
        catch (Exception $e) 
        {
            return Response::json(['status_code' => 500, 'error' => 'There is something wrong', 'status' => false], 500);
        }
    }
}
